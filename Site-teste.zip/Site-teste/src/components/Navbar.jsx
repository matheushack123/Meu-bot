import { Link } from 'react-router-dom'
import { Bot, Menu, X } from 'lucide-react'
import { useState } from 'react'
import './Navbar.css'

function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false)

  return (
    <nav className="navbar">
      <div className="container">
        <div className="navbar-content">
          <Link to="/" className="logo">
            <Bot size={32} />
            <span>HospedagemBot</span>
          </Link>

          <button className="menu-toggle" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>

          <div className={`nav-links ${menuOpen ? 'open' : ''}`}>
            <Link to="/" onClick={() => setMenuOpen(false)}>Início</Link>
            <Link to="/dashboard" onClick={() => setMenuOpen(false)}>Dashboard</Link>
            <Link to="/planos" onClick={() => setMenuOpen(false)}>Planos</Link>
            <Link to="/docs" onClick={() => setMenuOpen(false)}>Documentação</Link>
            <Link to="/upload" className="btn-primary" onClick={() => setMenuOpen(false)}>
              Hospedar Bot
            </Link>
          </div>
        </div>
      </div>
    </nav>
  )
}

export default Navbar
