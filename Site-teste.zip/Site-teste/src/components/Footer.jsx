import { Bot, Github, Twitter, MessageCircle } from 'lucide-react'
import './Footer.css'

function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <div className="footer-content">
          <div className="footer-section">
            <div className="footer-logo">
              <Bot size={28} />
              <span>HospedagemBot</span>
            </div>
            <p>Hospedagem profissional de bots Discord com alta performance e disponibilidade 24/7.</p>
          </div>

          <div className="footer-section">
            <h4>Links Rápidos</h4>
            <a href="/dashboard">Dashboard</a>
            <a href="/planos">Planos</a>
            <a href="/docs">Documentação</a>
            <a href="/upload">Hospedar Bot</a>
          </div>

          <div className="footer-section">
            <h4>Recursos</h4>
            <a href="/docs">API</a>
            <a href="/docs">Tutorial</a>
            <a href="/docs">Suporte</a>
            <a href="/docs">Status</a>
          </div>

          <div className="footer-section">
            <h4>Comunidade</h4>
            <div className="social-links">
              <a href="#" className="social-icon">
                <MessageCircle size={20} />
              </a>
              <a href="#" className="social-icon">
                <Github size={20} />
              </a>
              <a href="#" className="social-icon">
                <Twitter size={20} />
              </a>
            </div>
          </div>
        </div>

        <div className="footer-bottom">
          <p>&copy; 2024 HospedagemBot. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  )
}

export default Footer
