import { Link } from 'react-router-dom'
import { Zap, Shield, Clock, TrendingUp, Check } from 'lucide-react'
import './Home.css'

function Home() {
  return (
    <div className="home">
      <section className="hero">
        <div className="container">
          <div className="hero-content">
            <h1>Hospedagem Premium para Bots Discord</h1>
            <p>
              Mantenha seu bot online 24/7 com a melhor infraestrutura do Brasil.
              Deploy rápido, dashboard intuitivo e suporte profissional.
            </p>
            <div className="hero-buttons">
              <Link to="/upload" className="btn btn-large btn-primary">
                Começar Agora
              </Link>
              <Link to="/docs" className="btn btn-large btn-secondary">
                Ver Documentação
              </Link>
            </div>
          </div>
        </div>
      </section>

      <section className="features">
        <div className="container">
          <h2>Por que escolher HospedagemBot?</h2>
          <div className="features-grid">
            <div className="feature-card">
              <div className="feature-icon">
                <Zap size={32} />
              </div>
              <h3>Deploy em Segundos</h3>
              <p>Faça upload do seu bot e coloque-o online instantaneamente. Processo simples e rápido.</p>
            </div>

            <div className="feature-card">
              <div className="feature-icon">
                <Clock size={32} />
              </div>
              <h3>Uptime 24/7</h3>
              <p>Infraestrutura confiável com 99.9% de disponibilidade. Seu bot sempre online.</p>
            </div>

            <div className="feature-card">
              <div className="feature-icon">
                <Shield size={32} />
              </div>
              <h3>Proteção Anti-DDoS</h3>
              <p>Segurança de nível empresarial para proteger seus bots contra ataques.</p>
            </div>

            <div className="feature-card">
              <div className="feature-icon">
                <TrendingUp size={32} />
              </div>
              <h3>Alta Performance</h3>
              <p>Servidores AMD EPYC com SSDs NVMe para máximo desempenho.</p>
            </div>
          </div>
        </div>
      </section>

      <section className="languages">
        <div className="container">
          <h2>Suporte a Múltiplas Linguagens</h2>
          <div className="languages-grid">
            <div className="language-badge">JavaScript / Node.js</div>
            <div className="language-badge">Python</div>
            <div className="language-badge">Java</div>
            <div className="language-badge">TypeScript</div>
            <div className="language-badge">Go</div>
            <div className="language-badge">Rust</div>
          </div>
        </div>
      </section>

      <section className="cta">
        <div className="container">
          <div className="cta-content">
            <h2>Pronto para Começar?</h2>
            <p>Hospede seu bot Discord agora e aproveite 100MB de RAM grátis!</p>
            <Link to="/upload" className="btn btn-large btn-primary">
              Hospedar Meu Bot
            </Link>
          </div>
        </div>
      </section>
    </div>
  )
}

export default Home
