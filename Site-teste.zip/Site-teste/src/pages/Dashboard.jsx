import { useState } from 'react'
import { Play, Square, RotateCw, Trash2, Eye, TrendingUp, Cpu, HardDrive } from 'lucide-react'
import './Dashboard.css'

function Dashboard() {
  const [bots] = useState([
    {
      id: '1',
      name: 'MusicBot',
      status: 'online',
      ram: '150MB / 256MB',
      uptime: '15d 7h 32m',
      language: 'JavaScript'
    },
    {
      id: '2',
      name: 'ModerationBot',
      status: 'online',
      ram: '89MB / 128MB',
      uptime: '8d 2h 15m',
      language: 'Python'
    },
    {
      id: '3',
      name: 'UtilityBot',
      status: 'offline',
      ram: '0MB / 100MB',
      uptime: '-',
      language: 'TypeScript'
    }
  ])

  const [selectedBot, setSelectedBot] = useState(null)
  const [logs] = useState([
    '[2024-11-11 10:23:45] Bot iniciado com sucesso',
    '[2024-11-11 10:23:46] Conectado ao Discord Gateway',
    '[2024-11-11 10:23:46] Pronto! Logado como MusicBot#1234',
    '[2024-11-11 10:24:12] Comando /play executado por Usuario#1234',
    '[2024-11-11 10:25:33] Entrando no canal de voz: Música',
  ])

  const handleAction = (action, botId) => {
    console.log(`${action} bot ${botId}`)
  }

  return (
    <div className="dashboard">
      <div className="container">
        <div className="dashboard-header">
          <h1>Meus Bots</h1>
          <div className="stats">
            <div className="stat-card">
              <TrendingUp size={24} />
              <div>
                <div className="stat-value">{bots.filter(b => b.status === 'online').length}</div>
                <div className="stat-label">Online</div>
              </div>
            </div>
            <div className="stat-card">
              <Cpu size={24} />
              <div>
                <div className="stat-value">{bots.length}</div>
                <div className="stat-label">Total</div>
              </div>
            </div>
            <div className="stat-card">
              <HardDrive size={24} />
              <div>
                <div className="stat-value">534MB</div>
                <div className="stat-label">RAM Usada</div>
              </div>
            </div>
          </div>
        </div>

        <div className="bots-grid">
          {bots.map(bot => (
            <div key={bot.id} className="bot-card">
              <div className="bot-header">
                <div>
                  <h3>{bot.name}</h3>
                  <span className={`status-badge ${bot.status}`}>
                    {bot.status === 'online' ? '● Online' : '○ Offline'}
                  </span>
                </div>
                <span className="language-tag">{bot.language}</span>
              </div>

              <div className="bot-stats">
                <div className="bot-stat">
                  <span className="label">RAM:</span>
                  <span className="value">{bot.ram}</span>
                </div>
                <div className="bot-stat">
                  <span className="label">Uptime:</span>
                  <span className="value">{bot.uptime}</span>
                </div>
              </div>

              <div className="bot-actions">
                {bot.status === 'online' ? (
                  <button className="btn-action btn-stop" onClick={() => handleAction('stop', bot.id)}>
                    <Square size={16} /> Parar
                  </button>
                ) : (
                  <button className="btn-action btn-start" onClick={() => handleAction('start', bot.id)}>
                    <Play size={16} /> Iniciar
                  </button>
                )}
                <button className="btn-action" onClick={() => handleAction('restart', bot.id)}>
                  <RotateCw size={16} /> Restart
                </button>
                <button className="btn-action" onClick={() => setSelectedBot(bot)}>
                  <Eye size={16} /> Logs
                </button>
                <button className="btn-action btn-danger" onClick={() => handleAction('delete', bot.id)}>
                  <Trash2 size={16} /> Deletar
                </button>
              </div>
            </div>
          ))}
        </div>

        {selectedBot && (
          <div className="logs-section">
            <div className="logs-header">
              <h2>Logs - {selectedBot.name}</h2>
              <button className="btn-close" onClick={() => setSelectedBot(null)}>✕</button>
            </div>
            <div className="logs-container">
              {logs.map((log, index) => (
                <div key={index} className="log-line">{log}</div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default Dashboard
