import { Check } from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import './Planos.css'

function Planos() {
  const navigate = useNavigate()
  const plans = [
    {
      name: 'Gratuito',
      price: 'R$ 0',
      period: '/mês',
      features: [
        '100MB de RAM',
        '1 Bot Discord',
        'Uptime 24/7',
        'Suporte Básico',
        'Deploy Instantâneo',
        'Logs Básicos'
      ],
      popular: false
    },
    {
      name: 'Básico',
      price: 'R$ 9,90',
      period: '/mês',
      features: [
        '256MB de RAM',
        'Até 3 Bots Discord',
        'Uptime 99.9%',
        'Suporte Prioritário',
        'Deploy Instantâneo',
        'Logs Completos',
        'Auto Restart',
        'Backup Automático'
      ],
      popular: false
    },
    {
      name: 'Premium',
      price: 'R$ 19,90',
      period: '/mês',
      features: [
        '512MB de RAM',
        'Até 5 Bots Discord',
        'Uptime 99.9%',
        'Suporte VIP 24/7',
        'Deploy Instantâneo',
        'Logs Completos',
        'Auto Restart',
        'Backup Automático',
        'Domínio Personalizado',
        'API Access'
      ],
      popular: true
    },
    {
      name: 'Enterprise',
      price: 'R$ 49,90',
      period: '/mês',
      features: [
        '2GB de RAM',
        'Bots Ilimitados',
        'Uptime 99.99%',
        'Suporte Dedicado',
        'Deploy Instantâneo',
        'Logs Avançados',
        'Auto Restart',
        'Backup Diário',
        'Domínios Ilimitados',
        'API Premium',
        'Sistema de Moderadores',
        'SLA Garantido'
      ],
      popular: false
    }
  ]

  return (
    <div className="planos-page">
      <div className="container">
        <div className="planos-header">
          <h1>Planos e Preços</h1>
          <p>Escolha o plano ideal para o seu projeto. Sem taxas ocultas, cancele quando quiser.</p>
        </div>

        <div className="plans-grid">
          {plans.map((plan, index) => (
            <div key={index} className={`plan-card ${plan.popular ? 'popular' : ''}`}>
              {plan.popular && <div className="popular-badge">Mais Popular</div>}
              
              <div className="plan-header">
                <h3>{plan.name}</h3>
                <div className="plan-price">
                  <span className="price">{plan.price}</span>
                  <span className="period">{plan.period}</span>
                </div>
              </div>

              <ul className="plan-features">
                {plan.features.map((feature, idx) => (
                  <li key={idx}>
                    <Check size={20} />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>

              <button 
                className={`btn-plan ${plan.popular ? 'btn-popular' : ''}`}
                onClick={() => navigate('/checkout', { state: { plan } })}
              >
                {plan.price === 'R$ 0' ? 'Começar Grátis' : 'Assinar Agora'}
              </button>
            </div>
          ))}
        </div>

        <div className="faq-section">
          <h2>Perguntas Frequentes</h2>
          <div className="faq-grid">
            <div className="faq-item">
              <h4>Posso mudar de plano depois?</h4>
              <p>Sim! Você pode fazer upgrade ou downgrade do seu plano a qualquer momento.</p>
            </div>
            <div className="faq-item">
              <h4>Como funciona o período gratuito?</h4>
              <p>O plano gratuito é permanente e sem limitação de tempo. Ideal para testar a plataforma.</p>
            </div>
            <div className="faq-item">
              <h4>Quais formas de pagamento são aceitas?</h4>
              <p>Aceitamos PIX instantâneo. Pagamento rápido e seguro!</p>
            </div>
            <div className="faq-item">
              <h4>Existe reembolso?</h4>
              <p>Sim, oferecemos garantia de 7 dias. Se não ficar satisfeito, devolvemos 100% do valor.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Planos
