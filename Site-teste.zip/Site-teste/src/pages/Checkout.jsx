import { useState, useEffect } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { QRCodeSVG } from 'qrcode.react'
import { Copy, Check, ArrowLeft } from 'lucide-react'
import './Checkout.css'

function Checkout() {
  const location = useLocation()
  const navigate = useNavigate()
  const { plan } = location.state || {}
  
  const [copied, setCopied] = useState(false)
  const [pixCode, setPixCode] = useState('')

  const PIX_KEY = '21974079520'

  useEffect(() => {
    if (!plan) {
      navigate('/planos')
      return
    }

    const value = parseFloat(plan.price.replace('R$ ', '').replace(',', '.'))
    if (value > 0) {
      const code = generatePixCode(PIX_KEY, plan.name, value)
      setPixCode(code)
    }
  }, [plan, navigate])

  const generatePixCode = (pixKey, description, value) => {
    const payload = [
      '000201',
      '26',
      pixKey.length.toString().padStart(2, '0') + '0014br.gov.bcb.pix01' + pixKey.length.toString().padStart(2, '0') + pixKey,
      '52040000',
      '5303986',
      '54' + value.toFixed(2).length.toString().padStart(2, '0') + value.toFixed(2),
      '5802BR',
      '59' + 'HospedagemBot'.length.toString().padStart(2, '0') + 'HospedagemBot',
      '6009SAO PAULO',
      '62' + (description.length + 4).toString().padStart(2, '0') + '05' + description.length.toString().padStart(2, '0') + description,
      '6304'
    ].join('')

    const crc16 = calculateCRC16(payload)
    return payload + crc16
  }

  const calculateCRC16 = (str) => {
    let crc = 0xFFFF
    for (let i = 0; i < str.length; i++) {
      crc ^= str.charCodeAt(i) << 8
      for (let j = 0; j < 8; j++) {
        if (crc & 0x8000) {
          crc = (crc << 1) ^ 0x1021
        } else {
          crc = crc << 1
        }
      }
    }
    return (crc & 0xFFFF).toString(16).toUpperCase().padStart(4, '0')
  }

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(pixCode)
      setCopied(true)
      setTimeout(() => setCopied(false), 3000)
    } catch (err) {
      alert('Erro ao copiar. Tente selecionar e copiar manualmente.')
    }
  }

  if (!plan) {
    return null
  }

  const value = parseFloat(plan.price.replace('R$ ', '').replace(',', '.'))

  return (
    <div className="checkout-page">
      <div className="container">
        <button className="back-button" onClick={() => navigate('/planos')}>
          <ArrowLeft size={20} />
          Voltar para Planos
        </button>

        <div className="checkout-content">
          <div className="checkout-header">
            <h1>Finalizar Pagamento</h1>
            <p>Plano {plan.name} - {plan.price}/mês</p>
          </div>

          <div className="payment-section">
            <div className="plan-summary">
              <h3>Resumo do Pedido</h3>
              <div className="summary-item">
                <span>Plano:</span>
                <strong>{plan.name}</strong>
              </div>
              <div className="summary-item">
                <span>Valor:</span>
                <strong>{plan.price}</strong>
              </div>
              <div className="summary-item total">
                <span>Total a pagar:</span>
                <strong>{plan.price}</strong>
              </div>
            </div>

            {value > 0 && (
              <div className="pix-payment">
                <h3>Pagar com PIX</h3>
                <p className="pix-instructions">
                  Escaneie o QR Code com o app do seu banco ou copie o código abaixo
                </p>

                <div className="qr-code-container">
                  <QRCodeSVG 
                    value={pixCode}
                    size={250}
                    level="M"
                    includeMargin={true}
                  />
                </div>

                <div className="pix-code-section">
                  <label>Código PIX Copia e Cola</label>
                  <div className="pix-code-input">
                    <input 
                      type="text" 
                      value={pixCode} 
                      readOnly 
                      onClick={(e) => e.target.select()}
                    />
                    <button 
                      className={`copy-button ${copied ? 'copied' : ''}`}
                      onClick={copyToClipboard}
                    >
                      {copied ? (
                        <>
                          <Check size={18} />
                          Copiado!
                        </>
                      ) : (
                        <>
                          <Copy size={18} />
                          Copiar
                        </>
                      )}
                    </button>
                  </div>
                </div>

                <div className="payment-info">
                  <h4>Como pagar:</h4>
                  <ol>
                    <li>Abra o app do seu banco</li>
                    <li>Escolha pagar com PIX</li>
                    <li>Escaneie o QR Code ou cole o código</li>
                    <li>Confirme o pagamento de {plan.price}</li>
                    <li>Após o pagamento, seu plano será ativado automaticamente</li>
                  </ol>
                </div>

                <div className="pix-key-info">
                  <p><strong>Chave PIX:</strong> {PIX_KEY}</p>
                  <p><strong>Nome:</strong> HospedagemBot</p>
                </div>
              </div>
            )}

            {value === 0 && (
              <div className="free-plan">
                <h3>🎉 Plano Gratuito Ativado!</h3>
                <p>Você não precisa pagar nada. Seu plano gratuito já está ativo!</p>
                <button className="btn-primary" onClick={() => navigate('/upload')}>
                  Começar a Hospedar
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default Checkout
