import { Book, Code, Terminal, FileText } from 'lucide-react'
import './Docs.css'

function Docs() {
  return (
    <div className="docs-page">
      <div className="container">
        <div className="docs-header">
          <h1>Documentação</h1>
          <p>Tudo o que você precisa saber para hospedar seu bot Discord</p>
        </div>

        <div className="docs-content">
          <div className="docs-sidebar">
            <nav className="docs-nav">
              <a href="#getting-started" className="active">
                <Book size={20} />
                Começando
              </a>
              <a href="#upload">
                <FileText size={20} />
                Como Fazer Upload
              </a>
              <a href="#api">
                <Code size={20} />
                API REST
              </a>
              <a href="#cli">
                <Terminal size={20} />
                CLI
              </a>
            </nav>
          </div>

          <div className="docs-main">
            <section id="getting-started" className="doc-section">
              <h2>Começando</h2>
              <p>
                Bem-vindo ao HospedagemBot! Esta documentação irá guiá-lo através do processo
                de hospedagem do seu bot Discord em nossa plataforma.
              </p>

              <h3>Pré-requisitos</h3>
              <ul>
                <li>Um bot Discord criado no Discord Developer Portal</li>
                <li>Código do seu bot em JavaScript, Python, Java ou outra linguagem suportada</li>
                <li>Conta no HospedagemBot</li>
              </ul>

              <h3>Linguagens Suportadas</h3>
              <div className="code-block">
                <pre>{`- JavaScript (Node.js)
- TypeScript
- Python
- Java
- Go
- Rust
- PHP
- Ruby`}</pre>
              </div>
            </section>

            <section id="upload" className="doc-section">
              <h2>Como Fazer Upload</h2>
              
              <h3>1. Prepare seu Projeto</h3>
              <p>Antes de fazer upload, certifique-se de:</p>
              <ul>
                <li>Remover <code>node_modules</code>, <code>package-lock.json</code> (para Node.js)</li>
                <li>Remover <code>venv</code>, <code>__pycache__</code> (para Python)</li>
                <li>Incluir <code>package.json</code> ou <code>requirements.txt</code></li>
                <li>Configurar variáveis de ambiente em arquivo <code>.env</code></li>
              </ul>

              <h3>2. Estrutura do Projeto (Node.js)</h3>
              <div className="code-block">
                <pre>{`meubot/
├── index.js          # Arquivo principal
├── package.json      # Dependências
├── .env              # Variáveis de ambiente
└── commands/         # Seus comandos
    ├── ping.js
    └── help.js`}</pre>
              </div>

              <h3>3. Exemplo de .env</h3>
              <div className="code-block">
                <pre>{`DISCORD_TOKEN=seu_token_aqui
PREFIX=!
OWNER_ID=seu_id_discord`}</pre>
              </div>

              <h3>4. Comprima e Envie</h3>
              <p>
                Selecione todos os arquivos do projeto, comprima em formato .zip e faça
                upload através do painel de controle.
              </p>
            </section>

            <section id="api" className="doc-section">
              <h2>API REST</h2>
              
              <h3>Autenticação</h3>
              <p>Todas as requisições requerem um token de API que pode ser obtido no dashboard.</p>
              
              <div className="code-block">
                <pre>{`Headers:
Authorization: Bearer SEU_TOKEN_AQUI
Content-Type: application/json`}</pre>
              </div>

              <h3>Endpoints Principais</h3>
              
              <h4>GET /api/bots</h4>
              <p>Lista todos os seus bots</p>
              <div className="code-block">
                <pre>{`curl -H "Authorization: Bearer TOKEN" \\
  https://api.hospedagembot.com/api/bots`}</pre>
              </div>

              <h4>POST /api/bots/:id/start</h4>
              <p>Inicia um bot</p>
              <div className="code-block">
                <pre>{`curl -X POST \\
  -H "Authorization: Bearer TOKEN" \\
  https://api.hospedagembot.com/api/bots/123/start`}</pre>
              </div>

              <h4>POST /api/bots/:id/restart</h4>
              <p>Reinicia um bot</p>

              <h4>POST /api/bots/:id/stop</h4>
              <p>Para um bot</p>

              <h4>GET /api/bots/:id/logs</h4>
              <p>Obtém os logs de um bot</p>
            </section>

            <section id="cli" className="doc-section">
              <h2>CLI - Command Line Interface</h2>
              
              <h3>Instalação</h3>
              <div className="code-block">
                <pre>{`npm install -g hospedagembot-cli`}</pre>
              </div>

              <h3>Login</h3>
              <div className="code-block">
                <pre>{`hospedagembot login`}</pre>
              </div>

              <h3>Deploy de Bot</h3>
              <div className="code-block">
                <pre>{`hospedagembot deploy --name "MeuBot" --ram 256`}</pre>
              </div>

              <h3>Listar Bots</h3>
              <div className="code-block">
                <pre>{`hospedagembot list`}</pre>
              </div>

              <h3>Ver Logs</h3>
              <div className="code-block">
                <pre>{`hospedagembot logs BOT_ID`}</pre>
              </div>

              <h3>Controlar Bot</h3>
              <div className="code-block">
                <pre>{`hospedagembot start BOT_ID
hospedagembot stop BOT_ID
hospedagembot restart BOT_ID`}</pre>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Docs
