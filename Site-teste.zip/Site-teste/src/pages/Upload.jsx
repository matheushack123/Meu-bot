import { useState } from 'react'
import { Upload as UploadIcon, File, AlertCircle } from 'lucide-react'
import './Upload.css'

function Upload() {
  const [formData, setFormData] = useState({
    botId: '',
    botName: '',
    mainFile: 'index.js',
    ram: '100',
    language: 'javascript',
    autoRestart: true
  })

  const [file, setFile] = useState(null)

  const handleSubmit = (e) => {
    e.preventDefault()
    console.log('Uploading bot:', formData, file)
    alert('Demo: Bot enviado com sucesso! Em produção, isso faria o upload real.')
  }

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0]
    if (selectedFile) {
      if (selectedFile.name.endsWith('.zip')) {
        setFile(selectedFile)
      } else {
        alert('Por favor, envie apenas arquivos .zip')
      }
    }
  }

  return (
    <div className="upload-page">
      <div className="container">
        <div className="upload-header">
          <h1>Hospedar Novo Bot</h1>
          <p>Faça upload do seu bot e coloque-o online em segundos</p>
        </div>

        <div className="upload-content">
          <div className="upload-form-container">
            <form onSubmit={handleSubmit} className="upload-form">
              <div className="form-section">
                <h3>Informações do Bot</h3>
                
                <div className="form-group">
                  <label>ID do Bot Discord *</label>
                  <input
                    type="text"
                    placeholder="123456789012345678"
                    value={formData.botId}
                    onChange={(e) => setFormData({...formData, botId: e.target.value})}
                    required
                  />
                </div>

                <div className="form-group">
                  <label>Nome do Bot *</label>
                  <input
                    type="text"
                    placeholder="MeuBot"
                    value={formData.botName}
                    onChange={(e) => setFormData({...formData, botName: e.target.value})}
                    required
                  />
                </div>

                <div className="form-row">
                  <div className="form-group">
                    <label>Linguagem *</label>
                    <select
                      value={formData.language}
                      onChange={(e) => setFormData({...formData, language: e.target.value})}
                    >
                      <option value="javascript">JavaScript</option>
                      <option value="typescript">TypeScript</option>
                      <option value="python">Python</option>
                      <option value="java">Java</option>
                      <option value="go">Go</option>
                      <option value="rust">Rust</option>
                    </select>
                  </div>

                  <div className="form-group">
                    <label>Arquivo Principal *</label>
                    <input
                      type="text"
                      placeholder="index.js"
                      value={formData.mainFile}
                      onChange={(e) => setFormData({...formData, mainFile: e.target.value})}
                      required
                    />
                  </div>
                </div>

                <div className="form-group">
                  <label>RAM Alocada (MB) *</label>
                  <select
                    value={formData.ram}
                    onChange={(e) => setFormData({...formData, ram: e.target.value})}
                  >
                    <option value="100">100MB (Grátis)</option>
                    <option value="256">256MB</option>
                    <option value="512">512MB</option>
                    <option value="1024">1GB</option>
                    <option value="2048">2GB</option>
                  </select>
                </div>

                <div className="form-group checkbox-group">
                  <label className="checkbox-label">
                    <input
                      type="checkbox"
                      checked={formData.autoRestart}
                      onChange={(e) => setFormData({...formData, autoRestart: e.target.checked})}
                    />
                    Auto Restart (Reiniciar automaticamente em caso de erro)
                  </label>
                </div>
              </div>

              <div className="form-section">
                <h3>Upload do Código</h3>
                
                <div className="file-upload-area">
                  <input
                    type="file"
                    id="file-input"
                    accept=".zip"
                    onChange={handleFileChange}
                    style={{ display: 'none' }}
                  />
                  <label htmlFor="file-input" className="file-upload-label">
                    {file ? (
                      <>
                        <File size={48} />
                        <span className="file-name">{file.name}</span>
                        <span className="file-size">
                          {(file.size / 1024 / 1024).toFixed(2)} MB
                        </span>
                      </>
                    ) : (
                      <>
                        <UploadIcon size={48} />
                        <span>Clique ou arraste um arquivo .zip</span>
                        <span className="upload-hint">Máximo 100MB</span>
                      </>
                    )}
                  </label>
                </div>

                <div className="info-box">
                  <AlertCircle size={20} />
                  <div>
                    <strong>Importante:</strong> Remova node_modules, package-lock.json, 
                    venv e outros arquivos desnecessários antes de compactar.
                  </div>
                </div>
              </div>

              <button type="submit" className="btn-submit">
                <UploadIcon size={20} />
                Hospedar Bot
              </button>
            </form>
          </div>

          <div className="upload-instructions">
            <h3>Como Preparar seu Bot</h3>
            <ol>
              <li>
                <strong>Estruture seu projeto:</strong>
                <p>Organize seus arquivos com package.json ou requirements.txt</p>
              </li>
              <li>
                <strong>Remova arquivos desnecessários:</strong>
                <p>Delete node_modules, venv, .git e outros arquivos grandes</p>
              </li>
              <li>
                <strong>Configure variáveis de ambiente:</strong>
                <p>Use arquivos .env para token e configurações sensíveis</p>
              </li>
              <li>
                <strong>Comprima em .zip:</strong>
                <p>Selecione todos os arquivos e comprima em formato .zip</p>
              </li>
              <li>
                <strong>Faça upload:</strong>
                <p>Preencha as informações e envie seu arquivo .zip</p>
              </li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Upload
