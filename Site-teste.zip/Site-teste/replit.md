# HospedagemBot - Plataforma de Hospedagem de Bots Discord

## Visão Geral

HospedagemBot é uma plataforma web completa em português brasileiro para hospedagem de bots Discord, inspirada no DisCloud. O projeto fornece uma interface moderna e intuitiva para usuários fazerem upload, gerenciar e monitorar seus bots Discord através de um painel web profissional.

## Data da Última Atualização

11 de Novembro de 2024

## Preferências do Usuário

- Comunicação em português brasileiro
- Estilo de comunicação: linguagem simples e cotidiana

## Arquitetura do Sistema

### Stack Tecnológico Frontend

**Framework**: React 19.2.0 com Vite 7.2.2 como ferramenta de build

**Roteamento**: React Router DOM v7.9.5 para navegação client-side

**Biblioteca de Ícones**: Lucide React v0.553.0 para iconografia consistente

**Estilo**: CSS modular com arquivos CSS separados por componente/página

### Estrutura do Projeto

```
hospedagembot/
├── index.html              # HTML raiz
├── vite.config.js          # Configuração do Vite
├── package.json            # Dependências e scripts
├── src/
│   ├── main.jsx            # Ponto de entrada React
│   ├── App.jsx             # Componente principal com rotas
│   ├── styles/
│   │   └── global.css      # Estilos globais e variáveis CSS
│   ├── components/
│   │   ├── Navbar.jsx      # Barra de navegação
│   │   ├── Navbar.css
│   │   ├── Footer.jsx      # Rodapé
│   │   └── Footer.css
│   └── pages/
│       ├── Home.jsx        # Landing page
│       ├── Home.css
│       ├── Dashboard.jsx   # Gerenciamento de bots
│       ├── Dashboard.css
│       ├── Upload.jsx      # Upload de novos bots
│       ├── Upload.css
│       ├── Planos.jsx      # Planos e preços
│       ├── Planos.css
│       ├── Docs.jsx        # Documentação
│       └── Docs.css
```

### Funcionalidades Implementadas

#### 1. Landing Page (Home)
- Hero section com call-to-action
- Seção de features destacando diferenciais
- Linguagens suportadas
- Seção CTA final
- Design responsivo com gradientes

#### 2. Dashboard
- Visualização de estatísticas (bots online, total, RAM usada)
- Cards de bots com informações de status
- Controles de ação: Start, Stop, Restart, Delete
- Visualizador de logs em tempo real
- Badges de status (online/offline)
- Tags de linguagem
- Interface responsiva

#### 3. Sistema de Upload
- Formulário completo para configuração de bot
- Upload de arquivo .zip
- Campos: Bot ID, Nome, Linguagem, Arquivo Principal, RAM
- Auto-restart configurável
- Instruções passo a passo
- Validação de tipo de arquivo
- Design em duas colunas (formulário + instruções)

#### 4. Planos e Preços
- Grid de 4 planos (Gratuito, Básico, Premium, Enterprise)
- Badge "Mais Popular" no plano Premium
- Lista de features por plano
- Seção de FAQ
- Botões de ação personalizados

#### 5. Documentação
- Sidebar de navegação sticky
- Seções: Começando, Upload, API REST, CLI
- Exemplos de código formatados
- Documentação completa de endpoints
- Instruções detalhadas de uso

### Configuração de Desenvolvimento

**Servidor de Desenvolvimento**:
- Host: 0.0.0.0
- Porta: 5000
- allowedHosts habilitado (compatível com Replit)

**Scripts Disponíveis**:
- `npm run dev` - Inicia servidor de desenvolvimento
- `npm run build` - Build de produção
- `npm run preview` - Preview do build

### Tema e Design

**Paleta de Cores**:
- Primary: #5865F2 (azul Discord)
- Primary Dark: #4752C4
- Secondary: #57F287 (verde)
- Dark: #1a1a2e
- Dark Light: #2d2d44
- Success: #57F287
- Danger: #ED4245
- Warning: #FEE75C

**Características Visuais**:
- Background com gradiente roxo
- Cards com backdrop-filter e efeito glassmorphic
- Transições suaves
- Hover effects em todos os elementos interativos
- Design responsivo mobile-first

### Estado Atual da Aplicação

**Status**: Protótipo frontend funcional completo

**Implementação Atual**:
- Todas as interfaces visuais implementadas
- Navegação funcionando entre páginas
- Interações frontend (console.log para ações)
- Dados estáticos/mock para demonstração
- Validações básicas de formulário

**Próximos Passos para Produção**:

1. **Backend**:
   - API REST para gerenciamento de bots
   - Sistema de autenticação (Discord OAuth)
   - Upload e armazenamento de arquivos
   - Sistema de filas para deploy
   - Monitoramento de bots em tempo real

2. **Banco de Dados**:
   - Tabela de usuários
   - Tabela de bots
   - Logs e métricas
   - Planos e assinaturas

3. **Infraestrutura**:
   - Container orchestration (Docker/Kubernetes)
   - Sistema de isolamento de bots
   - Limitação de recursos por plano
   - Backup automático

4. **Segurança**:
   - Autenticação e autorização
   - Rate limiting
   - Validação e sanitização de uploads
   - Proteção contra DDoS

5. **Pagamentos**:
   - Integração com gateway de pagamento
   - Sistema de assinaturas
   - Gestão de upgrades/downgrades

### Dependências

```json
{
  "@types/node": "^22.13.11",
  "@vitejs/plugin-react": "^5.1.0",
  "lucide-react": "^0.553.0",
  "react": "^19.2.0",
  "react-dom": "^19.2.0",
  "react-router-dom": "^7.9.5",
  "vite": "^7.2.2"
}
```

### Workflow Configurado

- **Nome**: hospedagembot
- **Comando**: npm run dev
- **Porta**: 5000
- **Tipo**: webview
- **Status**: Ativo

## Decisões Arquiteturais

1. **React + Vite**: Escolhido por performance de desenvolvimento e build otimizado
2. **CSS Modular**: Arquivos CSS separados para melhor organização e manutenibilidade
3. **React Router**: SPA para experiência de navegação fluida
4. **Dados Mock**: Frontend independente permite desenvolvimento paralelo do backend
5. **Lucide Icons**: Biblioteca leve e moderna de ícones

## Linguagens Suportadas (Planejadas)

- JavaScript (Node.js)
- TypeScript
- Python
- Java
- Go
- Rust
- PHP
- Ruby

## Notas de Desenvolvimento

- O projeto está configurado como ES Module (type: "module")
- Vite está configurado para permitir acesso de qualquer host (necessário para Replit)
- Todos os estilos usam variáveis CSS para fácil customização de tema
- Design mobile-first com breakpoints em 768px e 968px
- Componentes preparados para integração com API REST futura
