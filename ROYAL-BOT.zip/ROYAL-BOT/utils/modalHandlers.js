const { EmbedBuilder } = require('discord.js');

module.exports = {
  async config_bot_modal(interaction, client) {
    const nome = interaction.fields.getTextInputValue('bot_nome');
    const foto = interaction.fields.getTextInputValue('bot_foto');

    const updates = {};

    if (nome) {
      updates.bot_name = nome;
      await interaction.client.user.setUsername(nome).catch(() => {});
    }

    if (foto) {
      updates.bot_avatar = foto;
      await interaction.client.user.setAvatar(foto).catch(() => {});
    }

    if (Object.keys(updates).length > 0) {
      client.db.updateConfig(interaction.guildId, updates);
    }

    await interaction.reply({ content: '✅ Configurações do bot atualizadas!', ephemeral: true });
  },

  async config_perms_modal(interaction, client) {
    const cargoPrincipal = interaction.fields.getTextInputValue('cargo_principal');
    const cargoMediador = interaction.fields.getTextInputValue('cargo_mediador');

    const updates = {};

    if (cargoPrincipal) updates.cargo_principal = cargoPrincipal;
    if (cargoMediador) updates.cargo_mediador = cargoMediador;

    client.db.updateConfig(interaction.guildId, updates);

    await interaction.reply({ content: '✅ Permissões configuradas!', ephemeral: true });
  },

  async ranking_coins_modal(interaction, client) {
    const vitorias = parseInt(interaction.fields.getTextInputValue('vitorias_partida'));
    const coins = parseInt(interaction.fields.getTextInputValue('coins_partida'));

    client.db.updateConfig(interaction.guildId, {
      vitorias_por_partida: vitorias,
      coins_por_partida: coins
    });

    await interaction.reply({ content: '✅ Vitórias e coins configurados!', ephemeral: true });
  },

  async config_logs_modal(interaction, client) {
    const iniciadas = interaction.fields.getTextInputValue('logs_iniciadas');
    const canceladas = interaction.fields.getTextInputValue('logs_canceladas');
    const finalizadas = interaction.fields.getTextInputValue('logs_finalizadas');

    const updates = {};

    if (iniciadas) updates.canal_logs_iniciadas = iniciadas;
    if (canceladas) updates.canal_logs_canceladas = canceladas;
    if (finalizadas) updates.canal_logs_finalizadas = finalizadas;

    client.db.updateConfig(interaction.guildId, updates);

    await interaction.reply({ content: '✅ Logs configurados!', ephemeral: true });
  },

  async categoria_apostas_modal(interaction, client) {
    const categoriaId = interaction.fields.getTextInputValue('categoria_id');

    client.db.updateConfig(interaction.guildId, { categoria_apostas: categoriaId });

    await interaction.reply({ content: '✅ Categoria de apostas configurada!', ephemeral: true });
  },

  async canal_apostas_modal(interaction, client) {
    const canalId = interaction.fields.getTextInputValue('canal_id');

    client.db.updateConfig(interaction.guildId, { canal_apostas: canalId });

    await interaction.reply({ content: '✅ Canal de apostas configurado!', ephemeral: true });
  },

  async valor_salas_modal(interaction, client) {
    const valor = parseInt(interaction.fields.getTextInputValue('valor'));

    client.db.updateConfig(interaction.guildId, { valor_sala: valor });

    await interaction.reply({ content: '✅ Valor das salas configurado!', ephemeral: true });
  },

  async gerenciar_valores_modal(interaction, client) {
    const acao = interaction.fields.getTextInputValue('acao').toLowerCase();
    const valor = parseFloat(interaction.fields.getTextInputValue('valor'));

    if (acao === 'adicionar') {
      client.db.addValorAposta(interaction.guildId, valor);
      await interaction.reply({ content: `✅ Valor R$ ${valor.toFixed(2)} adicionado!`, ephemeral: true });
    } else if (acao === 'remover') {
      client.db.removeValorAposta(interaction.guildId, valor);
      await interaction.reply({ content: `✅ Valor R$ ${valor.toFixed(2)} removido!`, ephemeral: true });
    } else {
      await interaction.reply({ content: '❌ Ação inválida! Use "adicionar" ou "remover".', ephemeral: true });
    }
  },

  async vitorias_coins_modal(interaction, client) {
    const vitorias = parseInt(interaction.fields.getTextInputValue('vitorias'));
    const coins = parseInt(interaction.fields.getTextInputValue('coins'));

    client.db.updateConfig(interaction.guildId, {
      vitorias_por_partida: vitorias,
      coins_por_partida: coins
    });

    await interaction.reply({ content: '✅ Vitórias e coins configurados!', ephemeral: true });
  },

  async streamers_modal(interaction, client) {
    const categoriaStreamers = interaction.fields.getTextInputValue('categoria_streamers');

    if (categoriaStreamers) {
      client.db.updateConfig(interaction.guildId, { categoria_streamers: categoriaStreamers });
    }

    await interaction.reply({ content: '✅ Categoria de streamers configurada!', ephemeral: true });
  },

  async setar_canais_modal(interaction, client) {
    const canais = interaction.fields.getTextInputValue('canais_filas');

    if (canais) {
      const canaisArray = canais.split(',').map(c => c.trim());
      
      const db = client.db.db;
      db.exec(`
        CREATE TABLE IF NOT EXISTS canais_filas (
          guild_id TEXT PRIMARY KEY,
          canais TEXT NOT NULL
        )
      `);
      
      const stmt = db.prepare('INSERT OR REPLACE INTO canais_filas (guild_id, canais) VALUES (?, ?)');
      stmt.run(interaction.guildId, canais);
    }

    await interaction.reply({ content: '✅ Canais das filas configurados!', ephemeral: true });
  },

  async config_embeds_modal(interaction, client) {
    const cor = interaction.fields.getTextInputValue('embed_cor');
    const titulo = interaction.fields.getTextInputValue('embed_titulo');
    const descricao = interaction.fields.getTextInputValue('embed_descricao');

    const db = client.db.db;
    db.exec(`
      CREATE TABLE IF NOT EXISTS config_embeds (
        guild_id TEXT PRIMARY KEY,
        cor TEXT DEFAULT '#00FF00',
        titulo TEXT DEFAULT NULL,
        descricao TEXT DEFAULT NULL
      )
    `);
    
    const stmt = db.prepare('INSERT OR REPLACE INTO config_embeds (guild_id, cor, titulo, descricao) VALUES (?, ?, ?, ?)');
    stmt.run(interaction.guildId, cor || '#00FF00', titulo || null, descricao || null);

    await interaction.reply({ content: '✅ Embeds configurados com sucesso!', ephemeral: true });
  },

  async vincular_conta_modal(interaction, client) {
    const email = interaction.fields.getTextInputValue('email_vinculo');
    const telefone = interaction.fields.getTextInputValue('telefone_vinculo');

    const db = client.db.db;
    db.exec(`
      CREATE TABLE IF NOT EXISTS vinculos_pix (
        user_id TEXT PRIMARY KEY,
        guild_id TEXT NOT NULL,
        email TEXT NOT NULL,
        telefone TEXT
      )
    `);
    
    const stmt = db.prepare('INSERT OR REPLACE INTO vinculos_pix (user_id, guild_id, email, telefone) VALUES (?, ?, ?, ?)');
    stmt.run(interaction.user.id, interaction.guildId, email, telefone || null);

    const { EmbedBuilder } = require('discord.js');
    const embed = new EmbedBuilder()
      .setTitle('✅ Conta Vinculada!')
      .setDescription(`
**Email:** ${email}
${telefone ? `**Telefone:** ${telefone}` : ''}

Sua conta foi vinculada com sucesso ao sistema PIX.
      `)
      .setColor('#00FF00')
      .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },

  async cadastrar_pix_modal(interaction, client) {
    const chave = interaction.fields.getTextInputValue('pix_chave');
    const nome = interaction.fields.getTextInputValue('pix_nome');

    client.db.updateUsuario(interaction.user.id, interaction.guildId, {
      pix_cadastrado: 1,
      pix_chave: chave,
      pix_nome: nome
    });

    const embed = new EmbedBuilder()
      .setTitle('✅ PIX Cadastrado com Sucesso!')
      .setDescription(`
**Chave PIX:** ${chave}
**Nome:** ${nome}

Seu PIX foi cadastrado e está aguardando verificação.
      `)
      .setColor('#00FF00')
      .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },

  async criar_sala_modal(interaction, client) {
    const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
    
    const idSala = interaction.fields.getTextInputValue('id_sala');
    const senhaSala = interaction.fields.getTextInputValue('senha_sala');

    const members = await interaction.channel.fetchStarterMessage().then(msg => {
      const mentions = msg.content.match(/<@(\d+)>/g);
      return mentions ? mentions.map(m => m.match(/\d+/)[0]) : [];
    }).catch(() => []);

    const jogadores = members.slice(0, 2);

    const embed = new EmbedBuilder()
      .setTitle('🎮 Sala Criada!')
      .setDescription(`
${jogadores.map(id => `<@${id}>`).join(' ')}

**ID da Sala:**
\`${idSala}\`

**Senha:**
\`${senhaSala}\`

Clique no botão abaixo para copiar o ID.
      `)
      .setColor('#00FF00')
      .setTimestamp();

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId(`copiar_id_${idSala}`)
          .setLabel('📋 Copiar ID')
          .setStyle(ButtonStyle.Primary)
      );

    await interaction.reply({
      content: jogadores.map(id => `<@${id}>`).join(' '),
      embeds: [embed],
      components: [row]
    });
  },
};
