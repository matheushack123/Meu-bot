const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, PermissionFlagsBits } = require('discord.js');

module.exports = {
  async config_filas(interaction, client) {
    const embed = new EmbedBuilder()
      .setTitle('Selecione onde configurar.')
      .setColor('#5865F2');

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('config_filas_select')
      .setPlaceholder('Escolha uma opção')
      .addOptions(
        new StringSelectMenuOptionBuilder()
          .setLabel('Configurar Embeds')
          .setDescription('Personalize os embeds das filas')
          .setValue('config_embeds')
          .setEmoji('⚙️'),
        new StringSelectMenuOptionBuilder()
          .setLabel('Categoria de Apostas')
          .setDescription('Defina a categoria onde irão cair as apostas')
          .setValue('categoria_apostas')
          .setEmoji('⚙️'),
        new StringSelectMenuOptionBuilder()
          .setLabel('Canal das Apostas')
          .setDescription('Canal onde irão cair as apostas')
          .setValue('canal_apostas')
          .setEmoji('⚙️'),
        new StringSelectMenuOptionBuilder()
          .setLabel('Valor das Salas')
          .setDescription('Valor das salas para cada jogador')
          .setValue('valor_salas')
          .setEmoji('⚙️'),
        new StringSelectMenuOptionBuilder()
          .setLabel('Gerenciar Valores')
          .setDescription('Adicione e remova valores para as apostas')
          .setValue('gerenciar_valores')
          .setEmoji('⚙️'),
        new StringSelectMenuOptionBuilder()
          .setLabel('Vitórias e Coins')
          .setDescription('Altere a quantidade de vitórias e coins que os jogadores ganham.')
          .setValue('vitorias_coins')
          .setEmoji('⚙️'),
        new StringSelectMenuOptionBuilder()
          .setLabel('Modo Full Ump Xm8')
          .setDescription('Ative ou desative o modo full.')
          .setValue('modo_full')
          .setEmoji('⚙️'),
        new StringSelectMenuOptionBuilder()
          .setLabel('Comando .p')
          .setDescription('Ative ou desative o comando .p nas filas.')
          .setValue('comando_p')
          .setEmoji('⚙️'),
        new StringSelectMenuOptionBuilder()
          .setLabel('Cadastro PIX restrito')
          .setDescription('Cadastro pix limitado.')
          .setValue('pix_restrito')
          .setEmoji('⚙️'),
        new StringSelectMenuOptionBuilder()
          .setLabel('Equilíbrio nas apostas')
          .setDescription('Define se os ADMs podem visualizar as apostas')
          .setValue('equilibrio_apostas')
          .setEmoji('⚙️'),
        new StringSelectMenuOptionBuilder()
          .setLabel('Setar Canais')
          .setDescription('Defina os canais onde as filas de apostas serão geradas')
          .setValue('setar_canais')
          .setEmoji('⚙️'),
        new StringSelectMenuOptionBuilder()
          .setLabel('Streamers')
          .setDescription('Configure as filas streamers.')
          .setValue('streamers')
          .setEmoji('⚙️')
      );

    const row = new ActionRowBuilder().addComponents(selectMenu);

    await interaction.reply({
      embeds: [embed],
      components: [row],
      ephemeral: true
    });
  },

  async config_perms(interaction, client) {
    const modal = new ModalBuilder()
      .setCustomId('config_perms_modal')
      .setTitle('Configurar Permissões');

    const cargoPrincipal = new TextInputBuilder()
      .setCustomId('cargo_principal')
      .setLabel('ID do Cargo Principal')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('ID do cargo')
      .setRequired(false);

    const cargoMediador = new TextInputBuilder()
      .setCustomId('cargo_mediador')
      .setLabel('ID do Cargo Mediador')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('ID do cargo')
      .setRequired(false);

    modal.addComponents(
      new ActionRowBuilder().addComponents(cargoPrincipal),
      new ActionRowBuilder().addComponents(cargoMediador)
    );

    await interaction.showModal(modal);
  },

  async ranking_coins(interaction, client) {
    const modal = new ModalBuilder()
      .setCustomId('ranking_coins_modal')
      .setTitle('Configurar Ranking e Coins');

    const vitorias = new TextInputBuilder()
      .setCustomId('vitorias_partida')
      .setLabel('Vitórias por partida')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('1')
      .setRequired(true);

    const coins = new TextInputBuilder()
      .setCustomId('coins_partida')
      .setLabel('Coins por partida')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('1')
      .setRequired(true);

    modal.addComponents(
      new ActionRowBuilder().addComponents(vitorias),
      new ActionRowBuilder().addComponents(coins)
    );

    await interaction.showModal(modal);
  },

  async config_logs(interaction, client) {
    const modal = new ModalBuilder()
      .setCustomId('config_logs_modal')
      .setTitle('Configurar Logs');

    const iniciadas = new TextInputBuilder()
      .setCustomId('logs_iniciadas')
      .setLabel('ID do Canal - Partidas Iniciadas')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('ID do canal')
      .setRequired(false);

    const canceladas = new TextInputBuilder()
      .setCustomId('logs_canceladas')
      .setLabel('ID do Canal - Partidas Canceladas')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('ID do canal')
      .setRequired(false);

    const finalizadas = new TextInputBuilder()
      .setCustomId('logs_finalizadas')
      .setLabel('ID do Canal - Partidas Finalizadas')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('ID do canal')
      .setRequired(false);

    modal.addComponents(
      new ActionRowBuilder().addComponents(iniciadas),
      new ActionRowBuilder().addComponents(canceladas),
      new ActionRowBuilder().addComponents(finalizadas)
    );

    await interaction.showModal(modal);
  },

  async atualizar_paineis(interaction, client) {
    await interaction.reply({ content: '✅ Painéis atualizados com sucesso!', ephemeral: true });
  },

  async entrar_fila_mediador(interaction, client) {
    const config = client.db.getConfig(interaction.guildId);

    if (config.cargo_mediador && !interaction.member.roles.cache.has(config.cargo_mediador)) {
      return interaction.reply({ content: '❌ Você não tem permissão para entrar na fila de mediadores!', ephemeral: true });
    }

    try {
      client.db.addMediadorFila(interaction.guildId, interaction.user.id);

      const mediadores = client.db.getAllMediadoresFila(interaction.guildId);
      const mediadoresLista = mediadores.map((m, i) => `${i + 1}. <@${m.mediador_id}>`).join('\n');

      const embed = new EmbedBuilder()
        .setTitle('Fila de Mediadores')
        .setDescription(mediadoresLista)
        .setColor('#00FF00')
        .setFooter({ text: 'Apenas mediadores podem entrar na fila' })
        .setTimestamp();

      await interaction.message.edit({ embeds: [embed] });
      await interaction.reply({ content: '✅ Você entrou na fila de mediadores!', ephemeral: true });
    } catch (error) {
      await interaction.reply({ content: '❌ Você já está na fila!', ephemeral: true });
    }
  },

  async sair_fila_mediador(interaction, client) {
    client.db.removeMediadorFila(interaction.guildId, interaction.user.id);

    const mediadores = client.db.getAllMediadoresFila(interaction.guildId);
    const mediadoresLista = mediadores.length > 0
      ? mediadores.map((m, i) => `${i + 1}. <@${m.mediador_id}>`).join('\n')
      : '*Nenhum mediador na fila*';

    const embed = new EmbedBuilder()
      .setTitle('Fila de Mediadores')
      .setDescription(mediadoresLista)
      .setColor('#00FF00')
      .setFooter({ text: 'Apenas mediadores podem entrar na fila' })
      .setTimestamp();

    await interaction.message.edit({ embeds: [embed] });
    await interaction.reply({ content: '✅ Você saiu da fila de mediadores!', ephemeral: true });
  },

  async comandos_mediador(interaction, client) {
    const embed = new EmbedBuilder()
      .setTitle('📋 Comandos do Mediador')
      .setDescription(`
**Menu Mediador:**
Use o botão "Menu Mediador" dentro das partidas para acessar:

• **Escolher vencedor** - Seleciona o vencedor da partida
• **Finalizar aposta** - Envia ID e senha da sala aos jogadores
• **Vitória por W.O** - Registra vitória por ausência do adversário
• **Revanche** - Cria uma nova partida entre os mesmos jogadores

**Fila de Mediadores:**
• Clique em "Entrar na fila" para ficar disponível
• Você será chamado automaticamente quando houver partidas
• Clique em "Sair da fila" quando não estiver disponível

**Cadastro PIX:**
• Use \`/cadastropix\` para cadastrar sua chave PIX
• Necessário para receber pagamentos das mediações
      `)
      .setColor('#5865F2')
      .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },

  async jogar_roleta(interaction, client) {
    const usuario = client.db.getUsuario(interaction.user.id, interaction.guildId);

    if (usuario.coins < 6) {
      return interaction.reply({ content: '❌ Você precisa de pelo menos 6 coins para jogar!', ephemeral: true });
    }

    client.db.updateUsuario(interaction.user.id, interaction.guildId, { coins: usuario.coins - 6 });

    const premios = [
      '2R$ NO PIX 💵',
      'CARGO MAGNATA 📛',
      '1R$ NO PIX 💵',
      'AP GRÁTIS 1,10',
      'CRIA DA ROYAL 🤴',
      'MIRA CAVALA 🔫',
      '4R$ NO PIX 💵'
    ];

    const premioGanho = premios[Math.floor(Math.random() * premios.length)];

    await interaction.reply({
      content: `🎰 Girando a roleta...\n\n🎉 Você ganhou: **${premioGanho}**!`,
      ephemeral: false
    });
  },

  async perfil_roleta(interaction, client) {
    const usuario = client.db.getUsuario(interaction.user.id, interaction.guildId);

    const embed = new EmbedBuilder()
      .setTitle(`Perfil de ${interaction.user.username}`)
      .setDescription(`
**💰 Coins:** ${usuario.coins}
**🏆 Vitórias:** ${usuario.vitorias}
**💀 Derrotas:** ${usuario.derrotas}
      `)
      .setColor('#9B59B6')
      .setThumbnail(interaction.user.displayAvatarURL())
      .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
  },

  async cadastrar_pix(interaction, client) {
    const modal = new ModalBuilder()
      .setCustomId('cadastrar_pix_modal')
      .setTitle('Cadastrar PIX');

    const chave = new TextInputBuilder()
      .setCustomId('pix_chave')
      .setLabel('Chave PIX')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('Digite sua chave PIX')
      .setRequired(true);

    const nome = new TextInputBuilder()
      .setCustomId('pix_nome')
      .setLabel('Nome do titular')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('Nome completo')
      .setRequired(true);

    modal.addComponents(
      new ActionRowBuilder().addComponents(chave),
      new ActionRowBuilder().addComponents(nome)
    );

    await interaction.showModal(modal);
  },

  async vincular_conta(interaction, client) {
    const modal = new ModalBuilder()
      .setCustomId('vincular_conta_modal')
      .setTitle('Vincular Conta PIX');

    const emailInput = new TextInputBuilder()
      .setCustomId('email_vinculo')
      .setLabel('Email da conta')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('seu@email.com')
      .setRequired(true);

    const telefoneInput = new TextInputBuilder()
      .setCustomId('telefone_vinculo')
      .setLabel('Telefone (opcional)')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('(00) 00000-0000')
      .setRequired(false);

    modal.addComponents(
      new ActionRowBuilder().addComponents(emailInput),
      new ActionRowBuilder().addComponents(telefoneInput)
    );

    await interaction.showModal(modal);
  },

  async verificar_cadastro(interaction, client) {
    const usuario = client.db.getUsuario(interaction.user.id, interaction.guildId);

    if (!usuario.pix_cadastrado) {
      return interaction.reply({ content: '❌ Você ainda não cadastrou seu PIX!', ephemeral: true });
    }

    const embed = new EmbedBuilder()
      .setTitle('✅ Cadastro PIX Verificado')
      .setDescription(`
**Chave PIX:** ${usuario.pix_chave}
**Nome:** ${usuario.pix_nome}
      `)
      .setColor('#00FF00')
      .setTimestamp();

    await interaction.reply({ embeds: [embed], ephemeral: true });
  }
};

const filaJogadores = {};

for (const buttonId of Object.keys(module.exports)) {
  if (buttonId.startsWith('jogar_') || buttonId.startsWith('sair_')) {
    module.exports[buttonId] = async function(interaction, client) {
      const parts = interaction.customId.split('_');
      const acao = parts[0];
      const modo = parts[1] + '-' + parts[2];
      const valor = parseFloat(parts[3]);

      const filaKey = `${interaction.guildId}_${modo}_${valor}`;

      if (!filaJogadores[filaKey]) {
        filaJogadores[filaKey] = [];
      }

      if (acao === 'jogar') {
        if (filaJogadores[filaKey].includes(interaction.user.id)) {
          return interaction.reply({ content: '❌ Você já está na fila!', ephemeral: true });
        }

        filaJogadores[filaKey].push(interaction.user.id);

        await interaction.reply({ content: '✅ Você entrou na fila!', ephemeral: true });

        if (filaJogadores[filaKey].length >= 2) {
          const jogador1 = filaJogadores[filaKey][0];
          const jogador2 = filaJogadores[filaKey][1];

          filaJogadores[filaKey] = filaJogadores[filaKey].slice(2);

          const thread = await interaction.channel.threads.create({
            name: `Partida ${modo} - R$ ${valor}`,
            autoArchiveDuration: 60,
            reason: 'Match encontrado'
          });

          await thread.send(`<@${jogador1}> <@${jogador2}>\n\n✅ Match encontrado! Combinem o estilo de jogo e confirmem quando estiverem prontos.`);

          const confirmRow = new ActionRowBuilder()
            .addComponents(
              new ButtonBuilder()
                .setCustomId(`confirmar_jogo_${thread.id}`)
                .setLabel('✅ Confirmar')
                .setStyle(ButtonStyle.Success)
            );

          await thread.send({ content: 'Clique para confirmar quando estiverem prontos:', components: [confirmRow] });
        }
      } else if (acao === 'sair') {
        const index = filaJogadores[filaKey].indexOf(interaction.user.id);
        if (index > -1) {
          filaJogadores[filaKey].splice(index, 1);
          await interaction.reply({ content: '✅ Você saiu da fila!', ephemeral: true });
        } else {
          await interaction.reply({ content: '❌ Você não está na fila!', ephemeral: true });
        }
      }

      const embed = interaction.message.embeds[0];
      const jogadoresTexto = filaJogadores[filaKey].length > 0
        ? filaJogadores[filaKey].map(id => `<@${id}>`).join('\n')
        : 'Nenhum jogador na fila';

      const newEmbed = EmbedBuilder.from(embed)
        .setDescription(embed.description.split('👥 **Jogadores:**')[0] + `👥 **Jogadores:**\n${jogadoresTexto}`);

      await interaction.message.edit({ embeds: [newEmbed] });
    };
  }
}

const confirmacoesJogo = {};

module.exports.confirmar_jogo = async function(interaction, client) {
  const threadId = interaction.customId.split('_')[2];

  if (!confirmacoesJogo[threadId]) {
    confirmacoesJogo[threadId] = [];
  }

  if (confirmacoesJogo[threadId].includes(interaction.user.id)) {
    return interaction.reply({ content: '❌ Você já confirmou!', ephemeral: true });
  }

  confirmacoesJogo[threadId].push(interaction.user.id);
  await interaction.reply({ content: '✅ Confirmado! Aguardando o outro jogador...', ephemeral: true });

  if (confirmacoesJogo[threadId].length >= 2) {
    await interaction.channel.send(`✅ Ambos os jogadores confirmaram! Aguardando mediador...`);

    const mediador = client.db.getMediadorFila(interaction.guildId);

    if (mediador) {
      await interaction.channel.send(`<@${mediador.mediador_id}> você foi chamado para mediar esta partida!`);

      const menuRow = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId(`menu_mediador_${threadId}`)
            .setLabel('Menu Mediador')
            .setStyle(ButtonStyle.Primary)
        );

      await interaction.channel.send({ content: 'Menu do mediador:', components: [menuRow] });
    }
  }
};

module.exports.menu_mediador = async function(interaction, client) {
  const selectMenu = new StringSelectMenuBuilder()
    .setCustomId('menu_mediador_select')
    .setPlaceholder('Escolha uma opção')
    .addOptions(
      new StringSelectMenuOptionBuilder()
        .setLabel('Escolher o vencedor')
        .setDescription('Escolha o vencedor da aposta.')
        .setValue('escolher_vencedor')
        .setEmoji('🥇'),
      new StringSelectMenuOptionBuilder()
        .setLabel('Finalizar aposta')
        .setDescription('Clique nessa opção para finalizar a aposta.')
        .setValue('finalizar_aposta')
        .setEmoji('✅'),
      new StringSelectMenuOptionBuilder()
        .setLabel('Vitória por W.O')
        .setDescription('Clique nessa opção para dar vitória por W.O.')
        .setValue('vitoria_wo')
        .setEmoji('⚔️'),
      new StringSelectMenuOptionBuilder()
        .setLabel('Revanche')
        .setDescription('Clique nessa opção para criar uma revanche desta aposta.')
        .setValue('revanche')
        .setEmoji('🔥')
    );

  const row = new ActionRowBuilder().addComponents(selectMenu);

  await interaction.reply({ content: 'Selecione uma opção:', components: [row], ephemeral: true });
};

