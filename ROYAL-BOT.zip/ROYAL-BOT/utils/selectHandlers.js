const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ModalBuilder, TextInputBuilder, TextInputStyle, PermissionFlagsBits } = require('discord.js');

module.exports = {
  async ticket_select(interaction, client) {
    const categoria = interaction.values[0];

    const categorias = {
      suporte: {
        nome: 'Suporte',
        emoji: '🎫',
        descricao: 'Aguarde que nossa equipe irá atendê-lo em breve.'
      },
      reembolso: {
        nome: 'Reembolso',
        emoji: '💰',
        descricao: 'Aguarde que nossa equipe irá processar seu reembolso.'
      },
      evento: {
        nome: 'Receber Evento',
        emoji: '🎁',
        descricao: 'Aguarde que nossa equipe irá processar seu evento.'
      },
      mediador: {
        nome: 'Vagas Mediador',
        emoji: '✅',
        descricao: 'Aguarde que nossa equipe irá avaliar sua candidatura.'
      }
    };

    const cat = categorias[categoria];

    const channel = await interaction.guild.channels.create({
      name: `${cat.emoji}-${interaction.user.username}`,
      type: 0,
      permissionOverwrites: [
        {
          id: interaction.guild.id,
          deny: [PermissionFlagsBits.ViewChannel],
        },
        {
          id: interaction.user.id,
          allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
        },
      ],
    });

    const embed = new EmbedBuilder()
      .setTitle(`${cat.emoji} | ${cat.nome.toUpperCase()}`)
      .setDescription(`${interaction.user}\n\n${cat.descricao}`)
      .setColor('#5865F2')
      .setTimestamp();

    await channel.send({ content: `${interaction.user}`, embeds: [embed] });

    await interaction.reply({ content: `✅ Ticket criado: ${channel}`, ephemeral: true });
  },

  async config_filas_select(interaction, client) {
    const opcao = interaction.values[0];

    switch (opcao) {
      case 'config_embeds':
        const modalEmbeds = new ModalBuilder()
          .setCustomId('config_embeds_modal')
          .setTitle('Configurar Embeds das Filas');

        const corEmbed = new TextInputBuilder()
          .setCustomId('embed_cor')
          .setLabel('Cor do Embed (HEX)')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('#00FF00')
          .setRequired(false);

        const tituloEmbed = new TextInputBuilder()
          .setCustomId('embed_titulo')
          .setLabel('Título do Embed')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('2x2 | ROYAL APOSTAS')
          .setRequired(false);

        const descricaoEmbed = new TextInputBuilder()
          .setCustomId('embed_descricao')
          .setLabel('Descrição do Embed')
          .setStyle(TextInputStyle.Paragraph)
          .setPlaceholder('Descrição personalizada das filas...')
          .setRequired(false);

        modalEmbeds.addComponents(
          new ActionRowBuilder().addComponents(corEmbed),
          new ActionRowBuilder().addComponents(tituloEmbed),
          new ActionRowBuilder().addComponents(descricaoEmbed)
        );
        await interaction.showModal(modalEmbeds);
        break;

      case 'categoria_apostas':
        const modalCategoria = new ModalBuilder()
          .setCustomId('categoria_apostas_modal')
          .setTitle('Categoria de Apostas');

        const categoriaInput = new TextInputBuilder()
          .setCustomId('categoria_id')
          .setLabel('ID da Categoria')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('ID da categoria')
          .setRequired(true);

        modalCategoria.addComponents(new ActionRowBuilder().addComponents(categoriaInput));
        await interaction.showModal(modalCategoria);
        break;

      case 'canal_apostas':
        const modalCanal = new ModalBuilder()
          .setCustomId('canal_apostas_modal')
          .setTitle('Canal das Apostas');

        const canalInput = new TextInputBuilder()
          .setCustomId('canal_id')
          .setLabel('ID do Canal')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('ID do canal')
          .setRequired(true);

        modalCanal.addComponents(new ActionRowBuilder().addComponents(canalInput));
        await interaction.showModal(modalCanal);
        break;

      case 'valor_salas':
        const modalValor = new ModalBuilder()
          .setCustomId('valor_salas_modal')
          .setTitle('Valor das Salas');

        const valorInput = new TextInputBuilder()
          .setCustomId('valor')
          .setLabel('Valor (para cada jogador)')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('15')
          .setRequired(true);

        modalValor.addComponents(new ActionRowBuilder().addComponents(valorInput));
        await interaction.showModal(modalValor);
        break;

      case 'gerenciar_valores':
        const modalGerenciar = new ModalBuilder()
          .setCustomId('gerenciar_valores_modal')
          .setTitle('Gerenciar Valores');

        const acao = new TextInputBuilder()
          .setCustomId('acao')
          .setLabel('Ação (adicionar/remover)')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('adicionar ou remover')
          .setRequired(true);

        const valorGerenciar = new TextInputBuilder()
          .setCustomId('valor')
          .setLabel('Valor (R$)')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('0.40')
          .setRequired(true);

        modalGerenciar.addComponents(
          new ActionRowBuilder().addComponents(acao),
          new ActionRowBuilder().addComponents(valorGerenciar)
        );
        await interaction.showModal(modalGerenciar);
        break;

      case 'vitorias_coins':
        const modalVitorias = new ModalBuilder()
          .setCustomId('vitorias_coins_modal')
          .setTitle('Vitórias e Coins');

        const vitorias = new TextInputBuilder()
          .setCustomId('vitorias')
          .setLabel('Vitórias por partida')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('1')
          .setRequired(true);

        const coins = new TextInputBuilder()
          .setCustomId('coins')
          .setLabel('Coins por partida')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('1')
          .setRequired(true);

        modalVitorias.addComponents(
          new ActionRowBuilder().addComponents(vitorias),
          new ActionRowBuilder().addComponents(coins)
        );
        await interaction.showModal(modalVitorias);
        break;

      case 'modo_full':
        const config = client.db.getConfig(interaction.guildId);
        const novoValor = !config.modo_full;
        client.db.updateConfig(interaction.guildId, { modo_full: novoValor });
        await interaction.reply({ content: `✅ Modo Full ${novoValor ? 'ativado' : 'desativado'}!`, ephemeral: true });
        break;

      case 'comando_p':
        const configP = client.db.getConfig(interaction.guildId);
        const novoP = !configP.comando_p_ativo;
        client.db.updateConfig(interaction.guildId, { comando_p_ativo: novoP });
        await interaction.reply({ content: `✅ Comando .p ${novoP ? 'ativado' : 'desativado'}!`, ephemeral: true });
        break;

      case 'pix_restrito':
        const configPix = client.db.getConfig(interaction.guildId);
        const novoPix = !configPix.cadastro_pix_restrito;
        client.db.updateConfig(interaction.guildId, { cadastro_pix_restrito: novoPix });
        await interaction.reply({ content: `✅ Cadastro PIX restrito ${novoPix ? 'ativado' : 'desativado'}!`, ephemeral: true });
        break;

      case 'equilibrio_apostas':
        const configEq = client.db.getConfig(interaction.guildId);
        const novoEq = !configEq.equilibrio_apostas;
        client.db.updateConfig(interaction.guildId, { equilibrio_apostas: novoEq });
        await interaction.reply({ content: `✅ Equilíbrio nas apostas ${novoEq ? 'ativado' : 'desativado'}!`, ephemeral: true });
        break;

      case 'setar_canais':
        const modalCanais = new ModalBuilder()
          .setCustomId('setar_canais_modal')
          .setTitle('Setar Canais das Filas');

        const canaisInput = new TextInputBuilder()
          .setCustomId('canais_filas')
          .setLabel('IDs dos Canais (separados por vírgula)')
          .setStyle(TextInputStyle.Paragraph)
          .setPlaceholder('123456789,987654321,456789123')
          .setRequired(false);

        modalCanais.addComponents(new ActionRowBuilder().addComponents(canaisInput));
        await interaction.showModal(modalCanais);
        break;

      case 'streamers':
        const modalStreamers = new ModalBuilder()
          .setCustomId('streamers_modal')
          .setTitle('Streamers');

        const categoriaStreamers = new TextInputBuilder()
          .setCustomId('categoria_streamers')
          .setLabel('ID da Categoria Streamers')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('ID da categoria')
          .setRequired(false);

        modalStreamers.addComponents(new ActionRowBuilder().addComponents(categoriaStreamers));
        await interaction.showModal(modalStreamers);
        break;
    }
  },

  async menu_mediador_select(interaction, client) {
    const opcao = interaction.values[0];

    switch (opcao) {
      case 'escolher_vencedor':
        await interaction.reply({ content: '🥇 Escolha o vencedor mencionando o jogador...', ephemeral: true });
        break;

      case 'finalizar_aposta':
        const { ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder } = require('discord.js');
        
        const modal = new ModalBuilder()
          .setCustomId('criar_sala_modal')
          .setTitle('Criar Sala');

        const idSala = new TextInputBuilder()
          .setCustomId('id_sala')
          .setLabel('ID da Sala')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('Digite o ID da sala')
          .setRequired(true);

        const senhaSala = new TextInputBuilder()
          .setCustomId('senha_sala')
          .setLabel('Senha da Sala')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('Digite a senha da sala')
          .setRequired(true);

        modal.addComponents(
          new ActionRowBuilder().addComponents(idSala),
          new ActionRowBuilder().addComponents(senhaSala)
        );

        await interaction.showModal(modal);
        break;

      case 'vitoria_wo':
        await interaction.reply({ content: '⚔️ Vitória por W.O registrada!', ephemeral: false });
        break;

      case 'revanche':
        await interaction.reply({ content: '🔥 Revanche criada!', ephemeral: false });
        break;
    }
  },
};
