const Database = require('better-sqlite3');
const path = require('path');

class BotDatabase {
  constructor() {
    this.db = new Database(path.join(__dirname, 'royal_apostas.db'));
    this.initTables();
  }

  initTables() {
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS config (
        guild_id TEXT PRIMARY KEY,
        bot_name TEXT DEFAULT 'ROYAL APOSTAS',
        bot_avatar TEXT DEFAULT NULL,
        categoria_apostas TEXT DEFAULT NULL,
        canal_apostas TEXT DEFAULT NULL,
        valor_sala INTEGER DEFAULT 15,
        vitorias_por_partida INTEGER DEFAULT 1,
        coins_por_partida INTEGER DEFAULT 1,
        modo_full BOOLEAN DEFAULT 0,
        comando_p_ativo BOOLEAN DEFAULT 1,
        cadastro_pix_restrito BOOLEAN DEFAULT 0,
        equilibrio_apostas BOOLEAN DEFAULT 1,
        cargo_principal TEXT DEFAULT NULL,
        cargo_mediador TEXT DEFAULT NULL,
        canal_logs_iniciadas TEXT DEFAULT NULL,
        canal_logs_canceladas TEXT DEFAULT NULL,
        canal_logs_finalizadas TEXT DEFAULT NULL,
        categoria_streamers TEXT DEFAULT NULL
      );

      CREATE TABLE IF NOT EXISTS valores_apostas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        valor REAL NOT NULL,
        UNIQUE(guild_id, valor)
      );

      CREATE TABLE IF NOT EXISTS filas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        nome TEXT NOT NULL,
        modo TEXT NOT NULL,
        canal_id TEXT NOT NULL,
        mensagem_id TEXT DEFAULT NULL,
        ativo BOOLEAN DEFAULT 1,
        embed_cor TEXT DEFAULT '#00FF00',
        embed_titulo TEXT DEFAULT NULL,
        embed_descricao TEXT DEFAULT NULL
      );

      CREATE TABLE IF NOT EXISTS fila_jogadores (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fila_id INTEGER NOT NULL,
        user_id TEXT NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (fila_id) REFERENCES filas(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS usuarios (
        user_id TEXT PRIMARY KEY,
        guild_id TEXT NOT NULL,
        vitorias INTEGER DEFAULT 0,
        derrotas INTEGER DEFAULT 0,
        coins INTEGER DEFAULT 0,
        pix_cadastrado BOOLEAN DEFAULT 0,
        pix_chave TEXT DEFAULT NULL,
        pix_nome TEXT DEFAULT NULL,
        mediador BOOLEAN DEFAULT 0
      );

      CREATE TABLE IF NOT EXISTS apostas (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        jogador1_id TEXT NOT NULL,
        jogador2_id TEXT NOT NULL,
        valor REAL NOT NULL,
        modo TEXT NOT NULL,
        mediador_id TEXT DEFAULT NULL,
        topico_id TEXT DEFAULT NULL,
        canal_privado_id TEXT DEFAULT NULL,
        status TEXT DEFAULT 'aguardando',
        vencedor_id TEXT DEFAULT NULL,
        id_sala TEXT DEFAULT NULL,
        senha_sala TEXT DEFAULT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
        finalizado_em DATETIME DEFAULT NULL
      );

      CREATE TABLE IF NOT EXISTS mediadores_fila (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        guild_id TEXT NOT NULL,
        mediador_id TEXT NOT NULL,
        timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS pix_mediadores (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        mediador_id TEXT NOT NULL,
        guild_id TEXT NOT NULL,
        pix_chave TEXT NOT NULL,
        pix_nome TEXT NOT NULL,
        verificado BOOLEAN DEFAULT 0,
        UNIQUE(mediador_id, guild_id)
      );
    `);

    console.log('✅ Database inicializado');
  }

  getConfig(guildId) {
    const stmt = this.db.prepare('SELECT * FROM config WHERE guild_id = ?');
    let config = stmt.get(guildId);

    if (!config) {
      const insert = this.db.prepare('INSERT INTO config (guild_id) VALUES (?)');
      insert.run(guildId);
      config = stmt.get(guildId);
    }

    return config;
  }

  updateConfig(guildId, updates) {
    const keys = Object.keys(updates);
    const values = Object.values(updates);
    const setClause = keys.map(key => `${key} = ?`).join(', ');

    const stmt = this.db.prepare(`UPDATE config SET ${setClause} WHERE guild_id = ?`);
    stmt.run(...values, guildId);
  }

  getValoresApostas(guildId) {
    const stmt = this.db.prepare('SELECT valor FROM valores_apostas WHERE guild_id = ? ORDER BY valor DESC');
    return stmt.all(guildId);
  }

  addValorAposta(guildId, valor) {
    const stmt = this.db.prepare('INSERT OR IGNORE INTO valores_apostas (guild_id, valor) VALUES (?, ?)');
    return stmt.run(guildId, valor);
  }

  removeValorAposta(guildId, valor) {
    const stmt = this.db.prepare('DELETE FROM valores_apostas WHERE guild_id = ? AND valor = ?');
    return stmt.run(guildId, valor);
  }

  getUsuario(userId, guildId) {
    const stmt = this.db.prepare('SELECT * FROM usuarios WHERE user_id = ? AND guild_id = ?');
    let user = stmt.get(userId, guildId);

    if (!user) {
      const insert = this.db.prepare('INSERT INTO usuarios (user_id, guild_id) VALUES (?, ?)');
      insert.run(userId, guildId);
      user = stmt.get(userId, guildId);
    }

    return user;
  }

  updateUsuario(userId, guildId, updates) {
    const keys = Object.keys(updates);
    const values = Object.values(updates);
    const setClause = keys.map(key => `${key} = ?`).join(', ');

    const stmt = this.db.prepare(`UPDATE usuarios SET ${setClause} WHERE user_id = ? AND guild_id = ?`);
    stmt.run(...values, userId, guildId);
  }

  getRanking(guildId, limit = 10) {
    const stmt = this.db.prepare(`
      SELECT user_id, vitorias, derrotas, coins 
      FROM usuarios 
      WHERE guild_id = ? 
      ORDER BY vitorias DESC, coins DESC 
      LIMIT ?
    `);
    return stmt.all(guildId, limit);
  }

  criarAposta(data) {
    const stmt = this.db.prepare(`
      INSERT INTO apostas (guild_id, jogador1_id, jogador2_id, valor, modo, mediador_id, topico_id, status)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
    return stmt.run(
      data.guildId,
      data.jogador1Id,
      data.jogador2Id,
      data.valor,
      data.modo,
      data.mediadorId,
      data.topicoId,
      data.status || 'aguardando'
    );
  }

  getAposta(id) {
    const stmt = this.db.prepare('SELECT * FROM apostas WHERE id = ?');
    return stmt.get(id);
  }

  updateAposta(id, updates) {
    const keys = Object.keys(updates);
    const values = Object.values(updates);
    const setClause = keys.map(key => `${key} = ?`).join(', ');

    const stmt = this.db.prepare(`UPDATE apostas SET ${setClause} WHERE id = ?`);
    stmt.run(...values, id);
  }

  addMediadorFila(guildId, mediadorId) {
    const stmt = this.db.prepare('INSERT INTO mediadores_fila (guild_id, mediador_id) VALUES (?, ?)');
    return stmt.run(guildId, mediadorId);
  }

  removeMediadorFila(guildId, mediadorId) {
    const stmt = this.db.prepare('DELETE FROM mediadores_fila WHERE guild_id = ? AND mediador_id = ?');
    return stmt.run(guildId, mediadorId);
  }

  getMediadorFila(guildId) {
    const stmt = this.db.prepare('SELECT mediador_id FROM mediadores_fila WHERE guild_id = ? ORDER BY timestamp ASC LIMIT 1');
    return stmt.get(guildId);
  }

  getAllMediadoresFila(guildId) {
    const stmt = this.db.prepare('SELECT mediador_id, timestamp FROM mediadores_fila WHERE guild_id = ? ORDER BY timestamp ASC');
    return stmt.all(guildId);
  }
}

module.exports = BotDatabase;
