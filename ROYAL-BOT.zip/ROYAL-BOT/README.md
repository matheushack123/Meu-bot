# 🎮 ROYAL APOSTAS BOT

Bot Discord completo para sistema de apostas e mediação de partidas.

## 📋 Funcionalidades

### ✅ Sistema de Filas
- Filas de apostas com diferentes modos (2x2, 1x1, Mobile, Royal)
- Botões JOGAR e SAIR para entrar/sair da fila
- Matchmaking automático quando 2 jogadores entram
- Criação de tópico privado para os jogadores combinarem o jogo

### 🛡️ Sistema de Mediadores
- Fila exclusiva para mediadores
- Menu do mediador com opções:
  - Escolher vencedor
  - Finalizar aposta
  - Vitória por W.O
  - Revanche

### 🎫 Sistema de Tickets
- 4 categorias: Suporte, Reembolso, Receber evento, Vagas mediador
- Criação automática de canais privados
- Sistema de notificação

### 🎰 Roleta
- Sistema de coins
- 6 coins = 1 giro
- Prêmios variados (PIX, cargos especiais, etc)

### 💳 Cadastro PIX
- Cadastro de chave PIX para mediadores
- Sistema de verificação
- Armazenamento seguro no banco de dados

### 🏆 Ranking e Perfil
- Sistema de vitórias e derrotas
- Coins por partida
- Ranking global do servidor
- Perfil individual de jogadores

### ⚙️ Painel de Configuração Completo
- Config Filas (embeds, valores, modos)
- Config Perms (cargos)
- Ranking e Coins
- Config Logs
- Configurar nome e foto do bot

## 🚀 Instalação

1. **Convide o bot para seu servidor:**

Substitua \`SEU_CLIENT_ID\` pelo ID da sua aplicação:

\`\`\`
https://discord.com/api/oauth2/authorize?client_id=SEU_CLIENT_ID&permissions=8&scope=bot%20applications.commands
\`\`\`

2. **Configure as variáveis de ambiente:**
- DISCORD_TOKEN (já configurado)
- CLIENT_ID (já configurado)
- GUILD_ID (já configurado)

3. **Inicie o bot:**
\`\`\`bash
npm start
\`\`\`

## 📝 Comandos

### Comandos de Administração
- \`/config\` - Painel de configuração principal
- \`/configbot\` - Configurar nome e foto do bot
- \`/fila\` - Criar fila de apostas
- \`/filamediador\` - Criar fila de mediadores
- \`/ticket\` - Sistema de tickets
- \`/roleta\` - Criar sistema de roleta
- \`/cadastropix\` - Painel de cadastro PIX

### Comandos Públicos
- \`/ranking\` - Ver ranking de jogadores
- \`/perfil [@usuario]\` - Ver perfil de um jogador

## 🗄️ Banco de Dados

O bot usa SQLite (better-sqlite3) para armazenar:
- Configurações do servidor
- Valores de apostas
- Filas de jogadores
- Dados dos usuários (vitórias, derrotas, coins, PIX)
- Apostas e histórico
- Fila de mediadores

## 🔧 Tecnologias

- **Discord.js v14** - Biblioteca principal
- **better-sqlite3** - Banco de dados
- **dotenv** - Gerenciamento de variáveis de ambiente
- **Node.js** - Runtime

## 📸 Screenshots

O bot foi desenvolvido baseado nas imagens fornecidas, replicando fielmente:
- Design dos embeds
- Botões interativos
- Sistema de filas
- Painel de configuração
- Menu do mediador
- Sistema de tickets

## 🎯 Próximos Passos

1. Convide o bot para seu servidor usando o link acima
2. Execute \`/config\` para configurar o bot
3. Configure os cargos de Principal e Mediador
4. Configure os canais de logs
5. Adicione valores de apostas
6. Crie as filas com \`/fila\`
7. Configure o sistema de tickets com \`/ticket\`

## 📞 Suporte

Em caso de dúvidas ou problemas, consulte a documentação do Discord.js ou entre em contato com o desenvolvedor.

---

**🎮 ROYAL APOSTAS - Sistema profissional de apostas e mediação**
