const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ranking')
    .setDescription('Ver ranking de jogadores'),

  async execute(interaction, client) {
    const ranking = client.db.getRanking(interaction.guildId, 10);

    if (ranking.length === 0) {
      return interaction.reply({ content: '❌ Ainda não há jogadores no ranking!', ephemeral: true });
    }

    let rankingTexto = '';
    ranking.forEach((jogador, index) => {
      const medalhas = ['🥇', '🥈', '🥉'];
      const emoji = index < 3 ? medalhas[index] : `${index + 1}.`;
      
      rankingTexto += `${emoji} <@${jogador.user_id}> - ${jogador.vitorias}V/${jogador.derrotas}D - ${jogador.coins} coins\n`;
    });

    const embed = new EmbedBuilder()
      .setTitle('🏆 Ranking Royal Apostas')
      .setDescription(rankingTexto)
      .setColor('#FFD700')
      .setFooter({ text: `Total de jogadores: ${ranking.length}` })
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
