const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('cadastropix')
    .setDescription('Painel de cadastro PIX para mediadores')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction, client) {
    const embed = new EmbedBuilder()
      .setTitle('Painel de Cadastro PIX Mediador')
      .setDescription('Clique nos botões abaixo para verificar ou cadastrar sua chave PIX.')
      .setColor('#00FF00')
      .setTimestamp();

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('cadastrar_pix')
          .setLabel('Cadastrar Pix')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('vincular_conta')
          .setLabel('Vincular Conta')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('verificar_cadastro')
          .setLabel('Verificar Cadastro')
          .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
          .setCustomId('tutorial_pix')
          .setLabel('Tutorial 🔗')
          .setStyle(ButtonStyle.Link)
          .setURL('https://discord.com')
      );

    await interaction.channel.send({
      embeds: [embed],
      components: [row]
    });

    await interaction.reply({ content: '✅ Painel de cadastro PIX criado!', ephemeral: true });
  },
};
