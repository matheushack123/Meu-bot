const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('perfil')
    .setDescription('Ver perfil de um jogador')
    .addUserOption(option =>
      option.setName('usuario')
        .setDescription('Usuário para ver o perfil')
        .setRequired(false)),

  async execute(interaction, client) {
    const usuario = interaction.options.getUser('usuario') || interaction.user;
    const dadosUsuario = client.db.getUsuario(usuario.id, interaction.guildId);

    const winrate = dadosUsuario.vitorias + dadosUsuario.derrotas > 0
      ? ((dadosUsuario.vitorias / (dadosUsuario.vitorias + dadosUsuario.derrotas)) * 100).toFixed(1)
      : 0;

    const embed = new EmbedBuilder()
      .setTitle(`Perfil de ${usuario.username}`)
      .setDescription(`
**🏆 Vitórias:** ${dadosUsuario.vitorias}
**💀 Derrotas:** ${dadosUsuario.derrotas}
**📊 Winrate:** ${winrate}%
**💰 Coins:** ${dadosUsuario.coins}
**💳 PIX Cadastrado:** ${dadosUsuario.pix_cadastrado ? '✅' : '❌'}
${dadosUsuario.mediador ? '**🛡️ Mediador:** ✅' : ''}
      `)
      .setColor('#5865F2')
      .setThumbnail(usuario.displayAvatarURL())
      .setTimestamp();

    await interaction.reply({ embeds: [embed] });
  },
};
