const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('fila')
    .setDescription('Criar uma fila de apostas')
    .addStringOption(option =>
      option.setName('modo')
        .setDescription('Modo de jogo')
        .setRequired(true)
        .addChoices(
          { name: '2x2 Mobile', value: '2x2-mob' },
          { name: '2x2 Royal', value: '2x2-royal' },
          { name: '1x1 Mobile', value: '1x1-mob' },
          { name: '1x1 Royal', value: '1x1-royal' }
        ))
    .addNumberOption(option =>
      option.setName('valor')
        .setDescription('Valor da aposta (R$)')
        .setRequired(true))
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction, client) {
    const modo = interaction.options.getString('modo');
    const valor = interaction.options.getNumber('valor');

    const modoNomes = {
      '2x2-mob': '2x2 | ROYAL APOSTAS - 2x2 Mobile',
      '2x2-royal': '2x2 | ROYAL APOSTAS - 2x2 Royal',
      '1x1-mob': '1x1 | ROYAL APOSTAS - 1x1 Mobile',
      '1x1-royal': '1x1 | ROYAL APOSTAS - 1x1 Royal'
    };

    const embed = new EmbedBuilder()
      .setTitle(modoNomes[modo])
      .setDescription(`
🎮 **Modo:**
${modo.includes('mob') ? '2x2 Mobile' : '2x2 Royal'}

💰 **Valor:**
R$ ${valor.toFixed(2)}

👥 **Jogadores:**
Nenhum jogador na fila
      `)
      .setColor('#00FF00')
      .setTimestamp();

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId(`jogar_${modo}_${valor}`)
          .setLabel('✅ JOGAR')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId(`sair_${modo}_${valor}`)
          .setLabel('❌ SAIR')
          .setStyle(ButtonStyle.Danger)
      );

    await interaction.channel.send({
      embeds: [embed],
      components: [row]
    });

    await interaction.reply({ content: '✅ Fila criada com sucesso!', ephemeral: true });
  },
};
