const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('filamediador')
    .setDescription('Criar fila de mediadores')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction, client) {
    const config = client.db.getConfig(interaction.guildId);
    const mediadores = client.db.getAllMediadoresFila(interaction.guildId);

    const mediadoresLista = mediadores.length > 0
      ? mediadores.map((m, i) => `${i + 1}. <@${m.mediador_id}>`).join('\n')
      : '*Nenhum mediador na fila*';

    const embed = new EmbedBuilder()
      .setTitle('Fila de Mediadores')
      .setDescription(`
${mediadoresLista}
      `)
      .setColor('#00FF00')
      .setFooter({ text: 'Apenas mediadores podem entrar na fila' })
      .setTimestamp();

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('entrar_fila_mediador')
          .setLabel('Entrar na fila')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('sair_fila_mediador')
          .setLabel('Sair da fila')
          .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
          .setCustomId('comandos_mediador')
          .setLabel('Comandos')
          .setStyle(ButtonStyle.Primary)
      );

    const message = await interaction.channel.send({
      embeds: [embed],
      components: [row]
    });

    await interaction.reply({ content: '✅ Fila de mediadores criada!', ephemeral: true });
  },
};
