const { SlashCommandBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('configbot')
    .setDescription('Configurar nome e foto do bot')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction, client) {
    const modal = new ModalBuilder()
      .setCustomId('config_bot_modal')
      .setTitle('Configurar Bot');

    const nomeInput = new TextInputBuilder()
      .setCustomId('bot_nome')
      .setLabel('Nome do Bot')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('ROYAL APOSTAS')
      .setRequired(false);

    const fotoInput = new TextInputBuilder()
      .setCustomId('bot_foto')
      .setLabel('URL da Foto do Bot')
      .setStyle(TextInputStyle.Short)
      .setPlaceholder('https://exemplo.com/foto.png')
      .setRequired(false);

    const row1 = new ActionRowBuilder().addComponents(nomeInput);
    const row2 = new ActionRowBuilder().addComponents(fotoInput);

    modal.addComponents(row1, row2);

    await interaction.showModal(modal);
  },
};
