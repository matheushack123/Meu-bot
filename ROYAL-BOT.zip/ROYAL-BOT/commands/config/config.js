const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('config')
    .setDescription('Painel de configuração do bot')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction, client) {
    const config = client.db.getConfig(interaction.guildId);
    const valores = client.db.getValoresApostas(interaction.guildId);

    const valoresTexto = valores.length > 0
      ? valores.map(v => `R$ ${v.valor.toFixed(2)},`).join('\n')
      : 'Nenhum valor configurado';

    const embed = new EmbedBuilder()
      .setTitle('Configurações do BOT')
      .setColor('#00FF00')
      .setDescription(`
**Configuração de Apostas:**
• **Cargo Principal:** ${config.cargo_principal ? `<@&${config.cargo_principal}>` : '❌'}
• **Cargo Mediador:** ${config.cargo_mediador ? `<@&${config.cargo_mediador}>` : '❌ MEDIADOR'}

**Valores nos paineis:**

${valoresTexto}

• **Valor das Salas:** ${config.valor_sala} (Para cada jogador)
• **Vitórias por partida:** ${config.vitorias_por_partida}
• **Coins por partida:** ${config.coins_por_partida}
• **Comando .p em filas:** ${config.comando_p_ativo ? '✅' : '⚪'}
• **Modo Full:** ${config.modo_full ? '✅' : '⚪'}
• **Cadastro PIX restrito:** ${config.cadastro_pix_restrito ? '✅' : '⚪'}
• **Equilíbrio nas apostas:** ${config.equilibrio_apostas ? '✅' : '⚪'}

**Configuração das Canais:**
• **Categoria das Apostas:** ${config.categoria_apostas ? `#${config.categoria_apostas}` : '❌SUAS APOSTAS »'}
• **Categoria dos Streamers:** ${config.categoria_streamers ? `#${config.categoria_streamers}` : '❌ 🔰 • Contra Streamers'}
• **Canal das Apostas:** ${config.canal_apostas ? `<#${config.canal_apostas}>` : '❌ 🎮 • royal-apostas'}

**Configuração das Logs:**
• **Canal logs partidas iniciadas:**
${config.canal_logs_iniciadas ? `<#${config.canal_logs_iniciadas}>` : '❌ iniciadas'}
• **Canal logs partidas canceladas:**
${config.canal_logs_canceladas ? `<#${config.canal_logs_canceladas}>` : '❌ canceladas'}
• **Canal logs partidas finalizadas:**
${config.canal_logs_finalizadas ? `<#${config.canal_logs_finalizadas}>` : '❌ finalizadas'}

${config.bot_name || 'ROYAL APOSTAS'}
      `)
      .setThumbnail(interaction.guild.iconURL())
      .setTimestamp();

    const row1 = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('config_filas')
          .setLabel('⚙️ Config filas')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('config_perms')
          .setLabel('⚙️ Config Perms')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('ranking_coins')
          .setLabel('⚙️ Ranking e Coins')
          .setStyle(ButtonStyle.Primary)
      );

    const row2 = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('config_logs')
          .setLabel('⚙️ Config Logs')
          .setStyle(ButtonStyle.Primary),
        new ButtonBuilder()
          .setCustomId('atualizar_paineis')
          .setLabel('Atualizar Paineis')
          .setStyle(ButtonStyle.Success)
      );

    await interaction.reply({
      embeds: [embed],
      components: [row1, row2],
      ephemeral: true
    });
  },
};
