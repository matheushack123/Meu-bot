const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('roleta')
    .setDescription('Criar sistema de roleta')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction, client) {
    const embed = new EmbedBuilder()
      .setTitle('ROYAL ROULETTE 🎰')
      .setDescription(`
Use suas coins para girar a roleta e concorrer a prêmios incríveis! A cada uma vitória vc recebe 1 coin🤑

**6 COIN = 1 GIRO**

**PRÊMIOS 🔥**

-----------

2R$ NO PIX   💵
CARGO MAGNATA  📛
1R$ NO PIX    💵
AP GRÁTIS 1,10
CRIA DA ROYAL 🤴
MIRA CAVALA   🔫
4R$ NO PIX    💵

-----------
      `)
      .setColor('#9B59B6')
      .setThumbnail(interaction.guild.iconURL())
      .setTimestamp();

    const row = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId('jogar_roleta')
          .setLabel('🎰 Jogar')
          .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
          .setCustomId('perfil_roleta')
          .setLabel('📋 Perfil')
          .setStyle(ButtonStyle.Primary)
      );

    await interaction.channel.send({
      embeds: [embed],
      components: [row]
    });

    await interaction.reply({ content: '✅ Roleta criada com sucesso!', ephemeral: true });
  },
};
