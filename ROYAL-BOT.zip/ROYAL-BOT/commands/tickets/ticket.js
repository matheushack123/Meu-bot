const { SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder, PermissionFlagsBits } = require('discord.js');

module.exports = {
  data: new SlashCommandBuilder()
    .setName('ticket')
    .setDescription('Sistema de tickets')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),

  async execute(interaction, client) {
    const embed = new EmbedBuilder()
      .setTitle('🎫 | TICKET ORG ROYAL')
      .setDescription(`
Precisa de ajuda? Está no lugar certo! Utilize as opções abaixo para falar com algum membro da Equipe da Royal.
      `)
      .setColor('#5865F2')
      .setThumbnail(interaction.guild.iconURL())
      .setTimestamp();

    const selectMenu = new StringSelectMenuBuilder()
      .setCustomId('ticket_select')
      .setPlaceholder('Selecione o ticket que deseja abrir')
      .addOptions(
        new StringSelectMenuOptionBuilder()
          .setLabel('Suporte')
          .setDescription('Selecione essa categoria para obter suporte')
          .setValue('suporte')
          .setEmoji('👤'),
        new StringSelectMenuOptionBuilder()
          .setLabel('Reembolso')
          .setDescription('Selecione essa categoria para receber reembolso')
          .setValue('reembolso')
          .setEmoji('💰'),
        new StringSelectMenuOptionBuilder()
          .setLabel('Receber evento')
          .setDescription('Selecione essa categoria para receber evento')
          .setValue('evento')
          .setEmoji('🎁'),
        new StringSelectMenuOptionBuilder()
          .setLabel('Vagas mediador')
          .setDescription('Selecione essa categoria para vagas de Adm')
          .setValue('mediador')
          .setEmoji('✅')
      );

    const row = new ActionRowBuilder().addComponents(selectMenu);

    await interaction.channel.send({
      embeds: [embed],
      components: [row]
    });

    await interaction.reply({ content: '✅ Sistema de tickets criado!', ephemeral: true });
  },
};
