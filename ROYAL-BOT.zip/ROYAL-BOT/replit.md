# Royal Apostas Bot

## Overview

Royal Apostas Bot is a Discord bot designed to manage betting systems and match mediation for gaming communities. The bot provides comprehensive features including betting queues, mediator management, ticket support, roulette games, player rankings, and PIX payment integration for Brazilian users.

The system handles matchmaking between players, automated match room creation, win/loss tracking, virtual currency (coins) management, and complete administrative configuration panels.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Application Framework
- **Platform**: Node.js Discord bot using Discord.js v14
- **Language**: JavaScript (Node.js)
- **Architecture Pattern**: Event-driven command handler pattern
- **Database**: Better-sqlite3 (embedded SQLite database)

**Rationale**: Discord.js provides a robust framework for Discord bot development with full API coverage. SQLite was chosen for its simplicity and zero-configuration deployment, suitable for a self-contained bot application without requiring external database servers.

### Core Components

#### Command System
- **Structure**: Slash commands organized by category folders (`admin/`, `config/`, `filas/`, `mediador/`, `roleta/`, `tickets/`)
- **Registration**: Separate deploy script (`deploy-commands.js`) for registering slash commands with Discord
- **Handler**: Centralized command collection and execution in `index.js`

**Rationale**: Discord's slash commands provide native autocomplete, validation, and better UX compared to prefix commands. Folder organization enables maintainability and logical grouping of features.

#### Event System
- **Events Handled**: 
  - `ready` - Bot initialization and status setting
  - `interactionCreate` - Handles all interaction types (commands, buttons, modals, select menus)
- **Pattern**: Event files in `events/` folder auto-loaded at startup

**Rationale**: Separating event logic from main bot file improves code organization and enables easier feature additions.

#### Interaction Handlers
- **Button Handler** (`utils/buttonHandlers.js`): Processes button clicks for queues, configuration, mediator actions
- **Modal Handler** (`utils/modalHandlers.js`): Processes form submissions for configuration settings
- **Select Menu Handler** (`utils/selectHandlers.js`): Handles dropdown menu selections for tickets and configuration

**Rationale**: Separating interaction handlers by type prevents a monolithic interaction handler and allows for focused, testable code units.

### Data Layer

#### Database Schema
The SQLite database (`royal_apostas.db`) contains several key tables:

1. **config**: Guild-specific configuration (bot settings, channels, roles, feature toggles)
2. **valores_apostas**: Betting value presets per guild
3. **filas**: Queue definitions with embed customization
4. **usuarios**: Player statistics (wins, losses, coins, PIX registration)
5. **apostas**: Active match records
6. **mediadores_fila**: Mediator queue tracking

**Rationale**: Guild-scoped configuration allows the bot to operate across multiple Discord servers with independent settings. Relational structure enables complex queries for rankings and matchmaking.

#### Database Class (`database/db.js`)
- **Pattern**: Singleton database wrapper
- **Initialization**: Auto-creates tables on first run
- **Operations**: Provides methods for CRUD operations on all entities

**Rationale**: Centralized database access ensures consistent connection handling and provides a clean API for database operations throughout the application.

### Feature Modules

#### Betting Queue System
- **Matchmaking**: Automatic pairing when required players join
- **Room Creation**: Discord thread/channel creation for matched players
- **Queue Management**: Join/leave buttons with real-time embed updates

**Design Decision**: Thread-based rooms provide isolated communication spaces that auto-archive, reducing server clutter.

#### Mediator System
- **Queue**: Separate queue for available mediators
- **Match Control**: Interface for selecting winners, handling W.O. (walkover), processing rematches
- **PIX Integration**: Mediator payment info registration and verification

**Design Decision**: Dedicated mediator role ensures trusted users control match outcomes and prevents cheating.

#### Ticket System
- **Categories**: Support, Refund, Event Reception, Mediator Applications
- **Channel Creation**: Private channels with specific permissions per ticket
- **Auto-categorization**: Tickets sorted by type

**Design Decision**: Private channel approach ensures user privacy and allows staff to manage tickets asynchronously.

#### Ranking & Profile System
- **Statistics Tracking**: Wins, losses, winrate calculation
- **Virtual Currency**: Coins awarded per match
- **Leaderboard**: Top 10 players by victories

**Design Decision**: Gamification through rankings and coins encourages player engagement and provides progression mechanics.

#### Configuration System
- **Admin Panel**: Master configuration command with button navigation
- **Modal Forms**: Text input for IDs and settings
- **Real-time Updates**: Configuration changes apply immediately

**Design Decision**: Interactive GUI-based configuration reduces errors compared to text commands and improves administrator experience.

## External Dependencies

### Discord API
- **Library**: discord.js v14.24.0
- **Purpose**: Primary interface to Discord API
- **Features Used**: Slash commands, buttons, modals, select menus, embeds, permissions, threads
- **Authentication**: Bot token stored in environment variables

### Database
- **Library**: better-sqlite3 v12.4.1
- **Type**: Embedded SQLite database
- **Storage**: Local file (`database/royal_apostas.db`)
- **No external server required**

### Environment Configuration
- **Library**: dotenv v17.2.3
- **Purpose**: Environment variable management
- **Required Variables**:
  - `DISCORD_TOKEN`: Bot authentication token
  - `CLIENT_ID`: Discord application client ID
  - `GUILD_ID`: Target Discord server ID for command registration

### Node.js Runtime
- **Required Version**: Node.js 16.11.0+ (per discord.js requirements)
- **Type Definitions**: @types/node for TypeScript support

### No External Services
The bot is fully self-contained with no external API dependencies, cloud services, or third-party integrations beyond Discord itself. All data is stored locally in SQLite.