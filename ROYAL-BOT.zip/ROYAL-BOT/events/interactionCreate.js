const { Events } = require('discord.js');

module.exports = {
  name: Events.InteractionCreate,
  async execute(interaction, client) {
    if (interaction.isChatInputCommand()) {
      const command = client.commands.get(interaction.commandName);

      if (!command) {
        console.error(`Comando ${interaction.commandName} não encontrado.`);
        return;
      }

      try {
        await command.execute(interaction, client);
      } catch (error) {
        console.error('Erro ao executar comando:', error);
        
        const errorMessage = { content: '❌ Ocorreu um erro ao executar este comando!', ephemeral: true };
        
        if (interaction.replied || interaction.deferred) {
          await interaction.followUp(errorMessage);
        } else {
          await interaction.reply(errorMessage);
        }
      }
    } else if (interaction.isButton()) {
      try {
        await handleButton(interaction, client);
      } catch (error) {
        console.error('Erro ao processar botão:', error);
      }
    } else if (interaction.isStringSelectMenu()) {
      try {
        await handleSelectMenu(interaction, client);
      } catch (error) {
        console.error('Erro ao processar select menu:', error);
      }
    } else if (interaction.isModalSubmit()) {
      try {
        await handleModal(interaction, client);
      } catch (error) {
        console.error('Erro ao processar modal:', error);
      }
    }
  },
};

async function handleButton(interaction, client) {
  const buttonHandlers = require('../utils/buttonHandlers');
  
  if (interaction.customId.startsWith('copiar_id_')) {
    const idSala = interaction.customId.replace('copiar_id_', '');
    await interaction.reply({
      content: `✅ ID copiado: \`${idSala}\`\n\nCole onde precisar!`,
      ephemeral: true
    });
    return;
  }
  
  if (buttonHandlers[interaction.customId]) {
    await buttonHandlers[interaction.customId](interaction, client);
  }
}

async function handleSelectMenu(interaction, client) {
  const selectHandlers = require('../utils/selectHandlers');
  
  if (selectHandlers[interaction.customId]) {
    await selectHandlers[interaction.customId](interaction, client);
  }
}

async function handleModal(interaction, client) {
  const modalHandlers = require('../utils/modalHandlers');
  
  if (modalHandlers[interaction.customId]) {
    await modalHandlers[interaction.customId](interaction, client);
  }
}
