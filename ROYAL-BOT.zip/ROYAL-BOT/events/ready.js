const { Events, ActivityType } = require('discord.js');

module.exports = {
  name: Events.ClientReady,
  once: true,
  execute(client) {
    console.log(`✅ Bot online como ${client.user.tag}`);
    console.log(`🎮 ROYAL APOSTAS - Sistema de apostas e mediação`);
    console.log(`📊 Servidores: ${client.guilds.cache.size}`);

    client.user.setActivity('Royal Apostas', { type: ActivityType.Playing });
  },
};
