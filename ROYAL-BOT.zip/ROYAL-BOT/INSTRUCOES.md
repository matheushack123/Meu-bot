# 📝 INSTRUÇÕES DE USO - ROYAL APOSTAS BOT

## 🚀 PASSO 1: Adicionar o Bot ao Servidor

**Use este link para convidar o bot:**

```
https://discord.com/api/oauth2/authorize?client_id=1431674531935948961&permissions=8&scope=bot%20applications.commands
```

1. Clique no link acima
2. Selecione seu servidor
3. Autorize todas as permissões
4. O bot entrará no servidor automaticamente

## ⚙️ PASSO 2: Registrar os Comandos

Depois que o bot entrar no servidor, execute:

```bash
npm run deploy
```

Isso registrará todos os comandos slash (/) no seu servidor.

## 🎮 PASSO 3: Configurar o Bot

### 3.1 Configuração Inicial

No Discord, use o comando:
```
/config
```

Isso abrirá o painel principal com todos os botões de configuração.

### 3.2 Configurar Permissões

Clique em **"Config Perms"** e defina:
- **Cargo Principal**: ID do cargo dos jogadores
- **Cargo Mediador**: ID do cargo dos mediadores

### 3.3 Configurar Logs

Clique em **"Config Logs"** e defina os canais:
- Canal de partidas iniciadas
- Canal de partidas canceladas
- Canal de partidas finalizadas

### 3.4 Configurar Valores

Use **"Config filas"** para:
- Adicionar valores de apostas (ex: 0.40, 0.50, 1.00, etc)
- Configurar categoria das apostas
- Configurar canal das apostas
- Ativar/desativar modo Full
- Ativar/desativar comando .p

## 📋 PASSO 4: Criar os Sistemas

### Sistema de Filas
```
/fila modo:2x2-mob valor:0.40
```

### Fila de Mediadores
```
/filamediador
```

### Sistema de Tickets
```
/ticket
```

### Sistema de Roleta
```
/roleta
```

### Cadastro PIX
```
/cadastropix
```

## 🎯 COMO FUNCIONA

### 1️⃣ Apostas
1. Jogador clica em **"JOGAR"** na fila
2. Quando 2 jogadores entram, o bot cria um tópico privado
3. Os jogadores confirmam que estão prontos
4. Um mediador da fila é chamado automaticamente
5. O mediador usa o **Menu Mediador** para gerenciar a partida

### 2️⃣ Menu do Mediador
- **Escolher vencedor**: Define quem ganhou
- **Finalizar aposta**: Envia ID e senha da sala
- **Vitória por W.O**: Registra vitória por ausência
- **Revanche**: Cria uma nova partida

### 3️⃣ Botão "Copiar ID"
Quando o mediador finaliza a aposta e envia o ID da sala, aparece um botão **"Copiar ID"** que facilita copiar o código.

### 4️⃣ Sistema de Coins e Ranking
- Jogadores ganham coins e vitórias a cada partida
- Use `/ranking` para ver o top 10
- Use `/perfil @usuario` para ver estatísticas

## 🔧 Comandos Disponíveis

### Administração
- `/config` - Painel de configuração
- `/configbot` - Mudar nome/foto do bot
- `/fila` - Criar fila de apostas
- `/filamediador` - Criar fila de mediadores
- `/ticket` - Sistema de tickets
- `/roleta` - Sistema de roleta
- `/cadastropix` - Painel PIX mediadores

### Públicos
- `/ranking` - Ver ranking
- `/perfil` - Ver perfil de jogador

## 💡 Dicas

1. **Configure primeiro** os cargos e canais antes de criar as filas
2. **Adicione vários valores** de apostas para dar opções aos jogadores
3. **Teste o sistema** com alguns jogadores antes de abrir para todos
4. **Mantenha mediadores** sempre na fila para agilizar as partidas

## ❓ Solução de Problemas

### Bot não responde aos comandos
- Verifique se executou `npm run deploy`
- Confirme que o bot tem as permissões corretas
- Reinicie o bot se necessário

### Comandos não aparecem
- Execute novamente `npm run deploy`
- Aguarde alguns minutos (pode demorar até 1 hora globalmente)
- Use comandos em um servidor específico (GUILD_ID configurado)

### Erro ao criar fila
- Verifique se configurou categoria e canal de apostas
- Confirme que o bot tem permissão para criar threads
- Verifique os logs do bot

## 🎊 Pronto!

Seu bot ROYAL APOSTAS está configurado e funcionando! 

Todos os botões, menus e funcionalidades das imagens fornecidas foram implementados:
✅ Config filas com todas as opções
✅ Config Perms  
✅ Ranking e Coins
✅ Config Logs
✅ Fila de mediadores
✅ Sistema de tickets
✅ Menu do mediador
✅ Botão "Copiar ID"
✅ Cadastro PIX
✅ Roleta
✅ Matchmaking com tópicos

Aproveite! 🎮
